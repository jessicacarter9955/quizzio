# Quiz Lab · Mobile Web v4

Responsive, offline-capable (standalone HTML) browser companion for Quiz Lab.

## Changes
- **Vocabulary / Phrasebook:** distinct study tracks. No combined Words + Phrases quiz.
- **Languages:** destination list excludes source, source list excludes destination; pair switches to a valid direction when necessary.
- **Multiple-choice game:** 5/10/20/30/50/100 questions, 4 answer options, results screen, retry, existing 3-2-1 progress and optional Anki self-rating.
- **Write it down:** blanked translation, first and last letter hints, reveal-and-skip. Correct, wrong, and revealed are recorded in `typingAttempts` without affecting multiple-choice mastery. Exact spelling except case/spacing; accented letters required.
- **Colors:** independent user-assigned neutral, red (different), yellow (similar), green (very similar), scoped to language pairs and shared with reversed direction. Search, only-unclassified, and load-more controls.
- **Analytics:** separate multiple-choice, writing and manual color totals, and category/subcategory breakdowns. Category/word selection remains persisted.

Vocabulary is the original Quiz Lab content, not a transcription of the proprietary DK dictionary. Phrasebook entries are only in the Phrasebook track. All data stored locally; no Supabase sync or cross-device integration. JavaScript app uses `data.js` from the prior verified source, with 1,871 items.

## Deployment
Render static site build command: `unzip -oq web-mobile-payload.zip -d public`
Publish directory: `public`.

## Tests
`node --check app.js` plus browser-interaction smoke tests with Playwright Chromium at 390x844: direction logic, phrase separation, colors, typed reveal/error, 5-question results, statistics and persistence. The Playwright tests exercise HTML, CSS and scripts together, in a sandbox origin with stub localStorage when direct navigation is blocked.
