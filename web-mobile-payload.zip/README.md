# Quiz Lab · Mobile web preview (2026-10-13)

Static, dependency-free, mobile-first browser companion sourced from the Quiz Lab Flutter curriculum JSON files. Includes **1,804 original curriculum entries (1,608 words and 196 phrases)** plus **67 entries from `language-quiz(1).json`**, for **1,871 total items**. The original 67-entry file supplies additional PT/RU/ZH/KO/JA variants, and the majority of the curriculum has EN/FR/DE/ES/IT translations.

## Run

Open `Quiz-Lab-Mobile-Standalone.html` in a browser for a completely self-contained, offline-capable preview. If a browser blocks local files, serve the directory with `python -m http.server 8000`, then open `http://localhost:8000/`.

`index.html` plus `data.js` and `app.js` is equivalent for static hosting. Deploy this directory to a static website host with publish path `web-mobile` if it lives in a GitHub repository.

## Features

- Mobile-first layout (full viewport on phones, centered 440px phone preview on desktop).
- Independent source, target and instruction language settings; instructions default to English.
- Hierarchical category → subcategory → word checkboxes and persisted exclusions.
- Separate vocabulary and phrase mode.
- Ranked priority based on wrong-answer counts, three-week 3/2/1 mastery, mastery reset after failures.
- Self-rated and automatic review, four answer choices.
- Daily activity, category/subcategory accuracy, and missed-word rankings.
- JSON vocabulary import (`{terms}` or `{version:1,entries}`), progress export and local browser storage.
- No accounts, remote API, cloud sync or Supabase credentials. Browser progress does NOT automatically sync with the Flutter APK.

## Testing

Using a Chromium mobile viewport (390×844), exercised: Home, Library, expand category/subcategory/word, Quiz (both modes), Stats, Settings language direction ES→PT (67 words), Phrase mode (196 items), and JSON file import. No browser JS errors observed. Unit / end-to-end tests are `test_browser.py` and `test_more.py`, which use Playwright and are separate from deployable site files.

## Caveats

This is a **web companion built from the project data and review rules**, not a compiled Flutter web artifact. No synchronization with the APK. Educational translations should be reviewed before production use.
