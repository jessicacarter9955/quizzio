import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Supabase is optional. Local SQLite and JSON imports remain usable without it.
/// Configure at build time with SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY.
class SupabaseQuizService extends ChangeNotifier {
  SupabaseQuizService._();
  static final SupabaseQuizService instance = SupabaseQuizService._();

  static const endpoint = String.fromEnvironment('SUPABASE_URL');
  static const publishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  bool _initialized = false;
  String? setupError;

  bool get configured => _initialized;
  SupabaseClient get _client {
    if (!_initialized) {
      throw StateError('Supabase is not configured. Add the URL and publishable key to the app build.');
    }
    return Supabase.instance.client;
  }

  User? get user => _initialized ? _client.auth.currentUser : null;
  bool get signedIn => user != null;
  String? get email => user?.email;

  Future<void> initialize() async {
    if (endpoint.trim().isEmpty || publishableKey.trim().isEmpty) return;
    if (_initialized) return;
    try {
      await Supabase.initialize(url: endpoint, publishableKey: publishableKey);
      _initialized = true;
      _client.auth.onAuthStateChange.listen((_) => notifyListeners());
    } catch (error) {
      // An invalid cloud configuration must never prevent local study.
      setupError = error.toString();
    }
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async {
    await _client.auth.signInWithPassword(email: email.trim(), password: password);
    notifyListeners();
  }

  /// Email confirmation may be required depending on Supabase project settings.
  Future<bool> signUp(String email, String password) async {
    final response = await _client.auth.signUp(email: email.trim(), password: password);
    notifyListeners();
    return response.session != null;
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
    notifyListeners();
  }

  /// Upserts an entire quiz or language pack with a stable ID. Re-uploading the
  /// same pack overwrites the JSON for that owner, not anybody else's data.
  Future<String> uploadPack(String jsonText) async {
    final activeUser = user;
    if (activeUser == null) throw StateError('Sign in to upload quizzes to Supabase.');
    final decoded = jsonDecode(jsonText);
    if (decoded is! Map<String, dynamic>) throw const FormatException('Expected a JSON object.');
    // The user's version:1 multilingual vocabulary JSON is also uploadable
    // without rewriting the source file. Store the original JSONB payload;
    // the app's importer converts it when downloaded on another device.
    final vocabularySchema = decoded['version'] == 1 &&
        decoded['entries'] is List && decoded['languages'] is List;
    final id = decoded['id'] ?? (vocabularySchema ? 'vocabulary-schema-v1' : null);
    final type = vocabularySchema ? 'language' : decoded['type'];
    final title = decoded['title'] ?? (vocabularySchema ? 'Multilingual vocabulary' : null);
    if (id is! String || id.trim().isEmpty ||
        title is! String || title.trim().isEmpty ||
        (type != 'quiz' && type != 'language')) {
      throw const FormatException('JSON must include a nonempty id, title and type (quiz or language).');
    }
    await _client.from('quiz_packs').upsert({
      'owner_id': activeUser.id,
      'pack_id': id.trim(),
      'pack_type': type,
      'title': title.trim(),
      'payload': decoded,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }, onConflict: 'owner_id,pack_id');
    return id.trim();
  }

  Future<List<String>> downloadPacks() async {
    final activeUser = user;
    if (activeUser == null) throw StateError('Sign in to download packs.');
    final rows = await _client.from('quiz_packs')
        .select('payload').eq('owner_id', activeUser.id).order('pack_id');
    return [for (final row in rows) jsonEncode(row['payload'])];
  }
}
