import 'package:flutter/material.dart';
import '../data/study_database.dart';
import '../domain/language_builder.dart';
import '../domain/review_engine.dart';
import '../models/quiz_models.dart';

class StudyState extends ChangeNotifier {
  final StudyDatabase db;
  StudyState(this.db);

  bool loading = true;
  String? loadError;
  List<QuizQuestion> normalQuestions = [];
  List<LanguageTerm> terms = [];
  Map<String, ReviewProgress> progress = {};
  String sourceLanguage = 'es';
  String targetLanguage = 'pt';
  String uiLanguage = 'en';
  TrafficLight? trafficFilter;
  String topicFilter = 'All';
  String languageTopicFilter = 'All';
  bool includeMastered = false;
  bool showOnlyDue = true;
  bool languageDueOnly = true;

  Future<void> initialize() async {
    try {
      await db.ensureStarterData();
      sourceLanguage = await db.setting('sourceLanguage') ?? 'es';
      targetLanguage = await db.setting('targetLanguage') ?? 'pt';
      uiLanguage = await db.setting('uiLanguage') ?? 'en';
      await refresh();
    } catch (error) {
      loadError = error.toString();
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> refresh() async {
    normalQuestions = await db.questions();
    terms = await db.languageTerms();
    progress = await db.allProgress();
    notifyListeners();
  }

  Future<int> importJson(String input) async {
    final count = await db.importJson(input);
    await refresh();
    return count;
  }

  Future<void> setLanguage(String property, String language) async {
    if (property == 'sourceLanguage') sourceLanguage = language;
    if (property == 'targetLanguage') targetLanguage = language;
    if (property == 'uiLanguage') uiLanguage = language;
    await db.saveSetting(property, language);
    notifyListeners();
  }

  List<String> get languageTopics =>
      <String>{for (final t in terms) t.topic}.toList()..sort();

  void setLanguageTopic(String topic) {
    languageTopicFilter = topic;
    notifyListeners();
  }

  void setLanguageDueOnly(bool value) {
    languageDueOnly = value;
    notifyListeners();
  }

  void setFilters({TrafficLight? traffic, bool clearTraffic = false,
      String? topic, bool? onlyDue, bool? mastered}) {
    if (clearTraffic) trafficFilter = null;
    if (traffic != null) {
      trafficFilter = traffic;
      if (traffic == TrafficLight.green) includeMastered = true;
    }
    if (topic != null) topicFilter = topic;
    if (onlyDue != null) showOnlyDue = onlyDue;
    if (mastered != null) {
      includeMastered = mastered;
      if (mastered) showOnlyDue = false;
    }
    notifyListeners();
  }

  List<QuizQuestion> languageQuestions() => LanguageBuilder.build(
      terms.where((t) => languageTopicFilter == 'All' || t.topic == languageTopicFilter).toList(),
      source: sourceLanguage, target: targetLanguage, uiLanguage: uiLanguage);

  ReviewProgress forQuestion(QuizQuestion question) =>
      progress[question.itemKey] ?? ReviewProgress.fresh(question.itemKey);

  List<String> get topics => <String>{for (final q in normalQuestions) q.topic}.toList()..sort();

  List<QuizQuestion> ordered(List<QuizQuestion> source, {bool applyFilters = true}) {
    final now = DateTime.now();
    final items = source.where((q) {
      final p = forQuestion(q);
      if (!applyFilters) return true;
      if (!includeMastered && p.mastered) return false;
      if (trafficFilter != null && ReviewEngine.traffic(p) != trafficFilter) return false;
      if (topicFilter != 'All' && q.topic != topicFilter) return false;
      if (showOnlyDue && trafficFilter != TrafficLight.green &&
          !ReviewEngine.due(p, now)) return false;
      return true;
    }).toList();
    items.sort((a, b) => ReviewEngine.comparePriority(forQuestion(a), forQuestion(b), now));
    return items;
  }

  Future<ReviewProgress> answer(QuizQuestion question, {
    required bool correct, required ReviewRating rating, required int elapsedMs,
  }) async {
    final updated = await db.logAnswer(question,
      correct: correct, rating: rating, timestamp: DateTime.now(), elapsedMs: elapsedMs);
    progress[question.itemKey] = updated;
    notifyListeners();
    return updated;
  }
}
