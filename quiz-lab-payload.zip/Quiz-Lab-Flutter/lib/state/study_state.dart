import 'package:flutter/material.dart';
import 'dart:convert';
import '../data/study_database.dart';
import '../domain/language_builder.dart';
import '../domain/review_engine.dart';
import '../models/quiz_models.dart';

class StudyState extends ChangeNotifier {
  final StudyDatabase db;
  StudyState(this.db);

  bool loading = true;
  String? loadError;
  List<QuizQuestion> normalQuestions = [];
  List<LanguageTerm> terms = [];
  Map<String, ReviewProgress> progress = {};
  String sourceLanguage = 'es';
  String targetLanguage = 'pt';
  String uiLanguage = 'en';
  TrafficLight? trafficFilter;
  String topicFilter = 'All';
  String languageTopicFilter = 'All';
  String languageCategoryFilter = 'All';
  String languageSubtopicFilter = 'All';
  // Exclusions are persisted; imported vocabulary is selected by default.
  final Set<String> excludedVocabularyIds = <String>{};
  TrafficLight? languageTrafficFilter;
  bool includeMastered = false;
  bool showOnlyDue = true;
  bool languageDueOnly = true;
  // The word/phrase selector is independent of the 3-week progress engine.
  String languageContentFilter = 'words'; // words, phrases or all

  Future<void> initialize() async {
    try {
      await db.ensureStarterData();
      sourceLanguage = await db.setting('sourceLanguage') ?? 'es';
      targetLanguage = await db.setting('targetLanguage') ?? 'pt';
      uiLanguage = await db.setting('uiLanguage') ?? 'en';
      languageContentFilter = await db.setting('languageContentFilter') ?? 'words';
      final savedExclusions = await db.setting('excludedVocabularyIds');
      if (savedExclusions != null) {
        final decoded = jsonDecode(savedExclusions);
        if (decoded is List) excludedVocabularyIds.addAll(decoded.map((e) => e.toString()));
      }
      await refresh();
    } catch (error) {
      loadError = error.toString();
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> refresh() async {
    normalQuestions = await db.questions();
    terms = await db.languageTerms();
    progress = await db.allProgress();
    notifyListeners();
  }

  Future<int> importJson(String input) async {
    final count = await db.importJson(input);
    await refresh();
    return count;
  }

  Future<void> setLanguage(String property, String language) async {
    if (property == 'sourceLanguage') sourceLanguage = language;
    if (property == 'targetLanguage') targetLanguage = language;
    if (property == 'uiLanguage') uiLanguage = language;
    await db.saveSetting(property, language);
    notifyListeners();
  }

  List<String> get languageTopics =>
      <String>{for (final t in terms) t.topic}.toList()..sort();

  static String getCategory(LanguageTerm t) => t.topic.contains(' / ')
      ? t.topic.split(' / ').first : t.topic;

  static String getSubtopic(LanguageTerm t) => t.topic.contains(' / ')
      ? t.topic.split(' / ').skip(1).join(' / ') : 'general';

  List<String> get languageCategories =>
      <String>{for (final t in terms) getCategory(t)}.toList()..sort();

  List<String> get languageSubtopics =>
      <String>{for (final t in terms)
        if (languageCategoryFilter == 'All' || getCategory(t) == languageCategoryFilter)
          getSubtopic(t)}.toList()..sort();

  void setLanguageCategory(String category) {
    languageCategoryFilter = category;
    languageSubtopicFilter = 'All';
    languageTopicFilter = 'All';
    notifyListeners();
  }

  void setLanguageSubtopic(String subtopic) {
    languageSubtopicFilter = subtopic;
    notifyListeners();
  }

  void setLanguageTopic(String topic) {
    languageTopicFilter = topic;
    notifyListeners();
  }

  void setLanguageDueOnly(bool value) {
    languageDueOnly = value;
    notifyListeners();
  }

  void setFilters({TrafficLight? traffic, bool clearTraffic = false,
      String? topic, bool? onlyDue, bool? mastered}) {
    if (clearTraffic) trafficFilter = null;
    if (traffic != null) {
      trafficFilter = traffic;
      if (traffic == TrafficLight.green) includeMastered = true;
    }
    if (topic != null) topicFilter = topic;
    if (onlyDue != null) showOnlyDue = onlyDue;
    if (mastered != null) {
      includeMastered = mastered;
      if (mastered) showOnlyDue = false;
    }
    notifyListeners();
  }

  String vocabularyId(LanguageTerm t) => '${t.packId}:${t.id}';

  bool vocabularySelected(LanguageTerm t) =>
      !excludedVocabularyIds.contains(vocabularyId(t));

  bool? vocabularyGroupSelection(Iterable<LanguageTerm> group) {
    final items = group.toList();
    if (items.isEmpty) return false;
    final selected = items.where(vocabularySelected).length;
    if (selected == 0) return false;
    if (selected == items.length) return true;
    return null;
  }

  Future<void> setVocabularySelection(Iterable<LanguageTerm> group, bool enabled) async {
    for (final term in group) {
      if (enabled) {
        excludedVocabularyIds.remove(vocabularyId(term));
      } else {
        excludedVocabularyIds.add(vocabularyId(term));
      }
    }
    notifyListeners();
    await db.saveSetting('excludedVocabularyIds', jsonEncode(excludedVocabularyIds.toList()..sort()));
  }

  Future<void> setLanguageContentFilter(String value) async {
    if (!['words', 'phrases', 'all'].contains(value)) return;
    languageContentFilter = value;
    notifyListeners();
    await db.saveSetting('languageContentFilter', value);
  }

  bool contentMatches(LanguageTerm term) => languageContentFilter == 'all' ||
      (languageContentFilter == 'words' && term.kind != 'phrase') ||
      (languageContentFilter == 'phrases' && term.kind == 'phrase');

  List<LanguageTerm> get filteredLanguageTerms =>
      terms.where(contentMatches).toList();

  void setLanguageTraffic(TrafficLight? value) {
    languageTrafficFilter = value;
    notifyListeners();
  }

  // Build distractors from ALL vocabulary; limit which source words are asked
  // only AFTER generating the multiple-choice questions. A selected group of
  // 1-3 words can therefore still have four valid answer options.
  List<QuizQuestion> allLanguageQuestions() => LanguageBuilder.build(terms,
      source: sourceLanguage, target: targetLanguage, uiLanguage: uiLanguage);

  List<QuizQuestion> languageQuestions() {
    final selectedIds = <String>{
      for (final t in filteredLanguageTerms) if (vocabularySelected(t)) vocabularyId(t),
    };
    return allLanguageQuestions().where((q) => selectedIds.contains(q.id)).toList();
  }

  /// Exactly one question per unique vocabulary item in this source->target
  /// direction. Counts do not multiply by 5 or by the number of translations.
  VocabularyGroupStats vocabularyStats(Iterable<LanguageTerm> input,
      Map<String, QuizQuestion> byId) {
    var selected = 0, available = 0, mastered = 0, due = 0;
    var red = 0, yellow = 0, green = 0, correct = 0, wrong = 0;
    final items = input.toList();
    final now = DateTime.now();
    for (final term in items) {
      if (!vocabularySelected(term)) continue;
      selected++;
      final q = byId[vocabularyId(term)];
      if (q == null) continue;
      available++;
      final p = forQuestion(q);
      if (p.mastered) mastered++;
      if (!p.mastered && ReviewEngine.due(p, now)) due++;
      switch (ReviewEngine.traffic(p)) {
        case TrafficLight.red: red++;
        case TrafficLight.yellow: yellow++;
        case TrafficLight.green: green++;
      }
      correct += p.correctTotal;
      wrong += p.wrongTotal;
    }
    return VocabularyGroupStats(total: items.length, selected: selected,
      available: available, mastered: mastered, due: due,
      red: red, yellow: yellow, green: green, correct: correct, wrong: wrong);
  }

  ReviewProgress forQuestion(QuizQuestion question) =>
      progress[question.itemKey] ?? ReviewProgress.fresh(question.itemKey);

  List<String> get topics => <String>{for (final q in normalQuestions) q.topic}.toList()..sort();

  List<QuizQuestion> ordered(List<QuizQuestion> source, {bool applyFilters = true}) {
    final now = DateTime.now();
    final items = source.where((q) {
      final p = forQuestion(q);
      if (!applyFilters) return true;
      if (!includeMastered && p.mastered) return false;
      if (trafficFilter != null && ReviewEngine.traffic(p) != trafficFilter) return false;
      if (topicFilter != 'All' && q.topic != topicFilter) return false;
      if (showOnlyDue && trafficFilter != TrafficLight.green &&
          !ReviewEngine.due(p, now)) return false;
      return true;
    }).toList();
    items.sort((a, b) => ReviewEngine.comparePriority(forQuestion(a), forQuestion(b), now));
    return items;
  }

  Future<ReviewProgress> answer(QuizQuestion question, {
    required bool correct, required ReviewRating rating, required int elapsedMs,
  }) async {
    final updated = await db.logAnswer(question,
      correct: correct, rating: rating, timestamp: DateTime.now(), elapsedMs: elapsedMs);
    progress[question.itemKey] = updated;
    notifyListeners();
    return updated;
  }
}

/// Aggregated live statistics for the currently selected source -> target pair.
/// `total` and `selected` count unique vocabulary IDs, not answer attempts.
class VocabularyGroupStats {
  final int total, selected, available, mastered, due;
  final int red, yellow, green, correct, wrong;
  const VocabularyGroupStats({required this.total, required this.selected,
    required this.available, required this.mastered, required this.due,
    required this.red, required this.yellow, required this.green,
    required this.correct, required this.wrong});
  int get attempts => correct + wrong;
  String get accuracy => attempts == 0 ? '—' : '${(100 * correct / attempts).round()}%';
}
