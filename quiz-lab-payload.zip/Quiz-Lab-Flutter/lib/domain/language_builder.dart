import '../models/quiz_models.dart';

const languageNames = <String, String>{
  'en': 'English', 'es': 'Spanish', 'pt': 'Portuguese',
  'it': 'Italian', 'fr': 'French', 'de': 'German', 'ru': 'Russian',
  'ja': 'Japanese', 'zh': 'Chinese', 'ko': 'Korean',
};

class LanguageBuilder {
  static String prompt(String sourceWord, String target, String uiLanguage) {
    final language = languageNames[target] ?? target;
    // All text OUTSIDE the quoted word is UI-language text.
    switch (uiLanguage) {
      case 'es': return '¿Cómo se dice "$sourceWord" en $language?';
      case 'pt': return 'Como se diz "$sourceWord" em $language?';
      case 'it': return 'Come si dice "$sourceWord" in $language?';
      case 'fr': return 'Comment dit-on "$sourceWord" en $language ?';
      case 'de': return 'Wie sagt man "$sourceWord" auf $language?';
      default: return 'How do you say "$sourceWord" in $language?';
    }
  }

  /// Generate stable multiple-choice questions from a parallel translation set.
  /// All options are in the TARGET language, regardless of the UI language.
  static List<QuizQuestion> build(
    List<LanguageTerm> terms, {
    required String source,
    required String target,
    String uiLanguage = 'en',
  }) {
    if (source == target) return [];
    final eligible = terms.where((term) =>
        (term.translations[source]?.trim().isNotEmpty ?? false) &&
        (term.translations[target]?.trim().isNotEmpty ?? false)).toList();
    final distinctAnswers = eligible.map((term) => term.translations[target]!.trim().toLowerCase()).toSet();
    if (distinctAnswers.length < 4) return [];
    final questions = <QuizQuestion>[];
    for (var index = 0; index < eligible.length; index++) {
      final term = eligible[index];
      final answer = term.translations[target]!.trim();
      final distractors = <String>[];
      // Rotate through pool deterministically instead of using random state.
      for (var offset = 1; offset < eligible.length && distractors.length < 3; offset++) {
        final candidate = eligible[(index + offset) % eligible.length].translations[target]!.trim();
        if (candidate.toLowerCase() != answer.toLowerCase() &&
            !distractors.any((v) => v.toLowerCase() == candidate.toLowerCase())) {
          distractors.add(candidate);
        }
      }
      if (distractors.length < 3) continue;
      final answerIndex = index % 4;
      final options = List<String>.from(distractors)..insert(answerIndex, answer);
      questions.add(QuizQuestion(
        id: '${term.packId}:${term.id}',
        packId: term.packId,
        topic: 'Languages / ${term.topic}',
        prompt: prompt(term.translations[source]!, target, uiLanguage),
        options: options,
        answerIndex: answerIndex,
        category: 'language',
        sourceLanguage: source,
        targetLanguage: target,
        explanation: '${term.translations[source]} → $answer',
      ));
    }
    return questions;
  }
}
