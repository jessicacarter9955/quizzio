import '../models/quiz_models.dart';

const languageNames = <String, String>{
  'en': 'English', 'es': 'Spanish', 'pt': 'Portuguese',
  'it': 'Italian', 'fr': 'French', 'de': 'German', 'ru': 'Russian',
  'ja': 'Japanese', 'zh': 'Chinese', 'ko': 'Korean',
  'ru_it': 'Russian (Latin)', 'zh_it': 'Chinese (Pinyin)',
  'ko_it': 'Korean (Romanization)', 'ja_it': 'Japanese (Romaji)',
};

class LanguageBuilder {
  static String prompt(String sourceWord, String target, String uiLanguage) {
    final language = languageNames[target] ?? target;
    // All text OUTSIDE the quoted word is UI-language text.
    switch (uiLanguage) {
      case 'es': return '¿Cómo se dice "$sourceWord" en $language?';
      case 'pt': return 'Como se diz "$sourceWord" em $language?';
      case 'it': return 'Come si dice "$sourceWord" in $language?';
      case 'fr': return 'Comment dit-on "$sourceWord" en $language ?';
      case 'de': return 'Wie sagt man "$sourceWord" auf $language?';
      default: return 'How do you say "$sourceWord" in $language?';
    }
  }

  /// Generate stable multiple-choice questions from a parallel translation set.
  /// All options are in the TARGET language, regardless of the UI language.
  static List<QuizQuestion> build(
    List<LanguageTerm> terms, {
    required String source,
    required String target,
    String uiLanguage = 'en',
  }) {
    if (source == target) return [];
    final candidates = terms.where((term) =>
        (term.translations[source]?.trim().isNotEmpty ?? false) &&
        (term.translations[target]?.trim().isNotEmpty ?? false)).toList();
    // Homographs/polysemy may share one source spelling (for example the
    // French word "pêche" can denote a peach or fishing). Include the
    // category context in the prompt when different target translations exist
    // instead of silently dropping both vocabulary cards.
    final meanings = <String, Set<String>>{};
    final byTopic = <String, List<LanguageTerm>>{};
    for (final term in candidates) {
      final key = term.translations[source]!.trim().toLowerCase();
      meanings.putIfAbsent(key, () => <String>{})
          .add(term.translations[target]!.trim().toLowerCase());
      byTopic.putIfAbsent(term.topic, () => <LanguageTerm>[]).add(term);
    }
    final eligible = candidates;
    final distinctAnswers = eligible
        .map((term) => term.translations[target]!.trim().toLowerCase())
        .toSet();
    if (distinctAnswers.length < 4) return [];
    final questions = <QuizQuestion>[];
    for (var index = 0; index < eligible.length; index++) {
      final term = eligible[index];
      final answer = term.translations[target]!.trim();
      final distractors = <String>[];
      // Rotate through pool deterministically instead of using random state.
      final pool = <LanguageTerm>[
        ...byTopic[term.topic]!.where((t) => t.id != term.id || t.packId != term.packId),
        ...eligible.where((t) => t.topic != term.topic),
      ];
      for (final other in pool) {
        if (distractors.length == 3) break;
        final candidate = other.translations[target]!.trim();
        if (candidate.toLowerCase() != answer.toLowerCase() &&
            !distractors.any((v) => v.toLowerCase() == candidate.toLowerCase())) {
          distractors.add(candidate);
        }
      }
      if (distractors.length < 3) continue;
      final answerIndex = index % 4;
      final options = List<String>.from(distractors)..insert(answerIndex, answer);
      questions.add(QuizQuestion(
        id: '${term.packId}:${term.id}',
        packId: term.packId,
        topic: 'Languages / ${term.topic}',
        prompt: prompt(
          meanings[term.translations[source]!.trim().toLowerCase()]!.length > 1
              ? '${term.translations[source]!} (${term.topic})'
              : term.translations[source]!,
          target,
          uiLanguage,
        ),
        options: options,
        answerIndex: answerIndex,
        category: 'language',
        sourceLanguage: source,
        targetLanguage: target,
        explanation: '${term.translations[source]} → $answer',
      ));
    }
    return questions;
  }
}
