import '../models/quiz_models.dart';

enum ReviewRating { again, hard, good, easy }
enum TrafficLight { red, yellow, green }

/// Three *consecutive* seven-day windows beginning with the first answer.
/// Week 1 requires >=3 correct answers, week 2 >=2, week 3 >=1.
/// Wrong answers add priority but do not count towards weekly correct totals.
/// Missing a week's quota starts a new three-week cycle on the next answer.
/// A wrong answer after mastery revokes mastery and starts a fresh cycle.
class ReviewEngine {
  static const weeklyTargets = [3, 2, 1];

  static DateTime _dateOnly(DateTime date) => DateTime(date.year, date.month, date.day);

  // UTC calendar dates avoid DST 23/25-hour day errors in weekly progress.
  static int elapsedDays(DateTime start, DateTime now) =>
      DateTime.utc(now.year, now.month, now.day)
          .difference(DateTime.utc(start.year, start.month, start.day)).inDays;

  static int weekIndex(ReviewProgress state, DateTime now) {
    final start = state.cycleStart;
    if (start == null) return 0;
    return elapsedDays(start, now) ~/ 7;
  }

  static int requiredThisWeek(ReviewProgress state, DateTime now) {
    final week = weekIndex(state, now);
    return week < 0 || week > 2 ? 3 : weeklyTargets[week];
  }

  static int correctThisWeek(ReviewProgress state, DateTime now) {
    switch (weekIndex(state, now)) {
      case 0:
        return state.week1;
      case 1:
        return state.week2;
      case 2:
        return state.week3;
      default:
        return 0;
    }
  }

  static bool due(ReviewProgress state, DateTime now) =>
      !state.mastered && (state.nextDue == null || !state.nextDue!.isAfter(now));

  static TrafficLight traffic(ReviewProgress state) {
    if (state.mastered) return TrafficLight.green;
    if (state.wrongStreak > 0 ||
        (state.wrongTotal > 0 && state.wrongTotal >= state.correctTotal)) {
      return TrafficLight.red;
    }
    return TrafficLight.yellow;
  }

  /// Wrong answers are the PRIMARY priority, then failed streak, then due.
  /// Mastered questions sink to the bottom and are hidden by default.
  static int comparePriority(ReviewProgress a, ReviewProgress b, DateTime now) {
    if (a.mastered != b.mastered) return a.mastered ? 1 : -1;
    final wrong = b.wrongTotal.compareTo(a.wrongTotal);
    if (wrong != 0) return wrong;
    final streak = b.wrongStreak.compareTo(a.wrongStreak);
    if (streak != 0) return streak;
    if (due(a, now) != due(b, now)) return due(a, now) ? -1 : 1;
    return a.itemId.compareTo(b.itemId);
  }

  static ReviewProgress record({
    required ReviewProgress previous,
    required DateTime now,
    required bool correct,
    required ReviewRating rating,
  }) {
    var start = previous.cycleStart ?? _dateOnly(now);
    var w1 = previous.week1;
    var w2 = previous.week2;
    var w3 = previous.week3;
    var mastered = previous.mastered;

    if (mastered && !correct) {
      start = _dateOnly(now);
      w1 = w2 = w3 = 0;
      mastered = false;
    }

    var week = elapsedDays(start, now) ~/ 7;
    // Detect missed milestones even if nobody opened the app that week.
    final missed = week < 0 || week > 2 ||
        (week >= 1 && w1 < 3) ||
        (week >= 2 && w2 < 2);
    if (!mastered && missed) {
      start = _dateOnly(now);
      w1 = w2 = w3 = 0;
      week = 0;
    }

    if (correct && !mastered) {
      if (week == 0) w1++;
      if (week == 1) w2++;
      if (week == 2) w3++;
      mastered = w1 >= 3 && w2 >= 2 && w3 >= 1;
    }

    final wrongStreak = correct ? 0 : previous.wrongStreak + 1;
    DateTime? next;
    if (!mastered) {
      Duration gap;
      if (!correct || rating == ReviewRating.again) {
        gap = const Duration(minutes: 5);
      } else {
        gap = switch (rating) {
          ReviewRating.hard => const Duration(hours: 6),
          ReviewRating.good => const Duration(days: 1),
          ReviewRating.easy => const Duration(days: 3),
          ReviewRating.again => const Duration(minutes: 5),
        };
      }
      next = now.add(gap);
      final count = week == 0 ? w1 : (week == 1 ? w2 : w3);
      final quota = weeklyTargets[week];
      final endOfWindow = DateTime(start.year, start.month,
          start.day + (week + 1) * 7);
      if (count >= quota) {
        // Don't quiz excessively when the week's requirement is complete.
        next = endOfWindow;
      } else if (next.isAfter(endOfWindow)) {
        // Preserve a chance to finish this week's requirement.
        next = endOfWindow.subtract(const Duration(minutes: 1));
      }
    }
    return ReviewProgress(
      itemId: previous.itemId,
      cycleStart: start,
      week1: w1,
      week2: w2,
      week3: w3,
      correctTotal: previous.correctTotal + (correct ? 1 : 0),
      wrongTotal: previous.wrongTotal + (correct ? 0 : 1),
      wrongStreak: wrongStreak,
      mastered: mastered,
      nextDue: next,
      lastAnswered: now,
    );
  }
}
