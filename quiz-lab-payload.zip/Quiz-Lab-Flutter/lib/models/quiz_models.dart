import 'dart:convert';

class QuizQuestion {
  final String id;
  final String packId;
  final String topic;
  final String prompt;
  final List<String> options;
  final int answerIndex;
  final String explanation;
  final String category; // quiz or language
  final String sourceLanguage;
  final String targetLanguage;

  const QuizQuestion({
    required this.id,
    required this.packId,
    required this.topic,
    required this.prompt,
    required this.options,
    required this.answerIndex,
    this.explanation = '',
    this.category = 'quiz',
    this.sourceLanguage = '',
    this.targetLanguage = '',
  });

  String get itemKey => category == 'language'
      ? 'language:$id:$sourceLanguage>$targetLanguage'
      : 'quiz:$packId:$id';

  Map<String, Object?> toDatabase() => {
        'id': itemKey,
        'raw_id': id,
        'pack_id': packId,
        'topic': topic,
        'prompt': prompt,
        'options_json': jsonEncode(options),
        'answer_index': answerIndex,
        'explanation': explanation,
      };

  factory QuizQuestion.fromDatabase(Map<String, Object?> row) => QuizQuestion(
        id: row['raw_id'] as String,
        packId: row['pack_id'] as String,
        topic: row['topic'] as String,
        prompt: row['prompt'] as String,
        options: (jsonDecode(row['options_json'] as String) as List).cast<String>(),
        answerIndex: row['answer_index'] as int,
        explanation: (row['explanation'] as String?) ?? '',
      );
}

class LanguageTerm {
  final String id;
  final String packId;
  final String topic;
  final Map<String, String> translations;

  const LanguageTerm({
    required this.id,
    required this.packId,
    required this.topic,
    required this.translations,
  });

  factory LanguageTerm.fromDatabase(Map<String, Object?> row) => LanguageTerm(
        id: row['id'] as String,
        packId: row['pack_id'] as String,
        topic: row['topic'] as String,
        translations: (jsonDecode(row['translations_json'] as String) as Map)
            .map((key, value) => MapEntry(key.toString(), value.toString())),
      );
}

class ReviewProgress {
  final String itemId;
  final DateTime? cycleStart;
  final int week1;
  final int week2;
  final int week3;
  final int correctTotal;
  final int wrongTotal;
  final int wrongStreak;
  final bool mastered;
  final DateTime? nextDue;
  final DateTime? lastAnswered;

  const ReviewProgress({
    required this.itemId,
    this.cycleStart,
    this.week1 = 0,
    this.week2 = 0,
    this.week3 = 0,
    this.correctTotal = 0,
    this.wrongTotal = 0,
    this.wrongStreak = 0,
    this.mastered = false,
    this.nextDue,
    this.lastAnswered,
  });

  factory ReviewProgress.fresh(String itemId) => ReviewProgress(itemId: itemId);

  factory ReviewProgress.fromDatabase(Map<String, Object?> row) => ReviewProgress(
        itemId: row['item_id'] as String,
        cycleStart: _date(row['cycle_start']),
        week1: row['week1'] as int,
        week2: row['week2'] as int,
        week3: row['week3'] as int,
        correctTotal: row['correct_total'] as int,
        wrongTotal: row['wrong_total'] as int,
        wrongStreak: row['wrong_streak'] as int,
        mastered: (row['mastered'] as int) != 0,
        nextDue: _date(row['next_due']),
        lastAnswered: _date(row['last_answered']),
      );

  Map<String, Object?> toDatabase() => {
        'item_id': itemId,
        'cycle_start': cycleStart?.toIso8601String(),
        'week1': week1,
        'week2': week2,
        'week3': week3,
        'correct_total': correctTotal,
        'wrong_total': wrongTotal,
        'wrong_streak': wrongStreak,
        'mastered': mastered ? 1 : 0,
        'next_due': nextDue?.toIso8601String(),
        'last_answered': lastAnswered?.toIso8601String(),
      };

  static DateTime? _date(Object? value) => value == null
      ? null
      : DateTime.tryParse(value.toString());
}

class AttemptRecord {
  final String itemId;
  final String topic;
  final String category;
  final String sourceLanguage;
  final String targetLanguage;
  final bool correct;
  final String rating;
  final DateTime timestamp;
  final int elapsedMs;

  const AttemptRecord({
    required this.itemId,
    required this.topic,
    required this.category,
    required this.sourceLanguage,
    required this.targetLanguage,
    required this.correct,
    required this.rating,
    required this.timestamp,
    required this.elapsedMs,
  });

  Map<String, Object?> toDatabase() => {
        'item_id': itemId,
        'topic': topic,
        'category': category,
        'source_lang': sourceLanguage,
        'target_lang': targetLanguage,
        'correct': correct ? 1 : 0,
        'rating': rating,
        'answered_at': timestamp.toIso8601String(),
        'elapsed_ms': elapsedMs,
      };
}
