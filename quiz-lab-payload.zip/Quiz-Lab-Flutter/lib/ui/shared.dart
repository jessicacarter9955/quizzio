import 'package:flutter/material.dart';
import '../domain/review_engine.dart';

const ink = Color(0xff111b33);
const deepBlue = Color(0xff151f3e);
const cyan = Color(0xff00d4bd);
const muted = Color(0xff8d9ab7);
const red = Color(0xffef5350);
const yellow = Color(0xffffc857);
const green = Color(0xff49c68d);

Color trafficColor(TrafficLight traffic) => switch (traffic) {
  TrafficLight.red => red,
  TrafficLight.yellow => yellow,
  TrafficLight.green => green,
};
String trafficName(TrafficLight traffic) => switch (traffic) {
  TrafficLight.red => 'Needs work',
  TrafficLight.yellow => 'Learning',
  TrafficLight.green => 'Mastered',
};

class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(18)});
  final Widget child;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: const Color(0xff24304f),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.white.withValues(alpha: .08)),
    ),
    child: child,
  );
}

class TrafficPill extends StatelessWidget {
  const TrafficPill({super.key, required this.traffic});
  final TrafficLight traffic;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: trafficColor(traffic).withValues(alpha: .17),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.circle, size: 10, color: trafficColor(traffic)),
      const SizedBox(width: 6),
      Text(trafficName(traffic), style: TextStyle(color: trafficColor(traffic), fontSize: 12, fontWeight: FontWeight.w700)),
    ]),
  );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.subtitle});
  final String title;
  final String? subtitle;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12, top: 12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: Colors.white)),
      if (subtitle != null) ...[const SizedBox(height: 3), Text(subtitle!, style: const TextStyle(color: muted))],
    ]),
  );
}

class NumberCard extends StatelessWidget {
  const NumberCard(this.value, this.label, this.icon, {super.key, this.tint = cyan});
  final String value;
  final String label;
  final IconData icon;
  final Color tint;
  @override
  Widget build(BuildContext context) => Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, color: tint, size: 21),
    const SizedBox(height: 12),
    Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
    const SizedBox(height: 3),
    Text(label, style: const TextStyle(fontSize: 12, color: muted)),
  ]));
}

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
