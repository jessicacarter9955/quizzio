import 'package:flutter/material.dart';
import '../cloud/supabase_quiz_service.dart';
import '../main.dart';
import 'shared.dart';

class CloudScreen extends StatefulWidget {
  const CloudScreen({super.key});
  @override
  State<CloudScreen> createState() => _CloudScreenState();
}

class _CloudScreenState extends State<CloudScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String? information;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> act(Future<String> Function() operation) async {
    if (busy) return;
    setState(() { busy = true; information = null; });
    try {
      final result = await operation();
      if (mounted) setState(() => information = result);
    } catch (e) {
      if (mounted) setState(() => information = 'Error: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cloud = SupabaseQuizService.instance;
    return ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 28), children: [
      const SectionTitle('Supabase Cloud', subtitle: 'Sign in to publish JSON quiz packs securely and restore them onto another device.'),
      if (!cloud.configured) Panel(child: Text(
        cloud.setupError == null
          ? 'Cloud is not configured in this build. Build with SUPABASE_URL and '
            'SUPABASE_PUBLISHABLE_KEY, then run supabase/schema.sql in your Supabase project. '
            'Offline quizzes remain available. Never put a secret/service-role key into this app.'
          : 'Cloud connection setup failed: ${cloud.setupError}. Offline quizzes still work.')),
      if (cloud.configured && !cloud.signedIn) Panel(child: Column(children: [
        TextField(controller: email, keyboardType: TextInputType.emailAddress,
          autocorrect: false, decoration: const InputDecoration(labelText: 'Email')),
        const SizedBox(height: 12),
        TextField(controller: password, obscureText: true, autocorrect: false,
          decoration: const InputDecoration(labelText: 'Password')),
        const SizedBox(height: 12),
        ElevatedButton.icon(onPressed: busy ? null : () => act(() async {
          await cloud.signIn(email.text, password.text);
          return 'Signed in as ${cloud.email}';
        }), icon: const Icon(Icons.login), label: const Text('Sign in')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: busy ? null : () => act(() async {
          final verified = await cloud.signUp(email.text, password.text);
          return verified ? 'Account created and signed in.' :
            'Check your email to confirm the account, then sign in.';
        }), icon: const Icon(Icons.person_add), label: const Text('Create account')),
      ])),
      if (cloud.configured && cloud.signedIn) ...[
        Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Connected: ${cloud.email ?? cloud.user!.id}'),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: busy ? null : () => act(() async {
            await cloud.signOut();
            return 'Signed out. Local questions and study history remain available.';
          }), child: const Text('Sign out')),
        ])),
        const SizedBox(height: 16),
        ElevatedButton.icon(onPressed: busy ? null : () => act(() async {
          final packs = await cloud.downloadPacks();
          var entries = 0;
          for (final pack in packs) {
            entries += await StudyScope.of(context).importJson(pack);
          }
          return 'Downloaded ${packs.length} JSON packs ($entries entries) to this device. '
            'Existing local progress is preserved.';
        }), icon: const Icon(Icons.cloud_download_outlined),
          label: const Text('Download my Supabase quizzes')),
        const SizedBox(height: 9),
        const Text('To upload a new JSON pack, go to Library and tap Upload JSON → Supabase. '
          'Uploads are private to your signed-in account.', style: TextStyle(color: muted)),
      ],
      if (busy) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
      if (information != null) Padding(padding: const EdgeInsets.only(top: 16), child: Panel(child: Text(information!))),
    ]);
  }
}
