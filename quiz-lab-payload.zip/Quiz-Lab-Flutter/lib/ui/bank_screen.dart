import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../main.dart';
import '../cloud/supabase_quiz_service.dart';
import 'shared.dart';

class BankScreen extends StatefulWidget {
  const BankScreen({super.key});
  @override
  State<BankScreen> createState() => _BankScreenState();
}

class _BankScreenState extends State<BankScreen> {
  final controller = TextEditingController();
  bool importing = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _import(String input) async {
    if (importing) return;
    setState(() => importing = true);
    try {
      final count = await StudyScope.of(context).importJson(input);
      if (!mounted) return;
      showMessage(context, 'Imported $count entries. Existing answer history was preserved.');
      controller.clear();
    } catch (e) {
      if (mounted) showMessage(context, 'Import failed: $e');
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> _upload(String input) async {
    if (importing) return;
    setState(() => importing = true);
    try {
      final cloud = SupabaseQuizService.instance;
      if (!cloud.configured) {
        throw StateError('Cloud not configured. Open the Cloud tab for setup instructions.');
      }
      if (!cloud.signedIn) {
        throw StateError('Sign in on the Cloud tab before uploading.');
      }
      // Validate and persist a complete pack offline before publishing it.
      final count = await StudyScope.of(context).importJson(input);
      final packId = await cloud.uploadPack(input);
      if (mounted) showMessage(context,
          'Uploaded "$packId" ($count items) to Supabase and stored it offline.');
    } catch (e) {
      if (mounted) showMessage(context, 'Upload failed: $e. If local import '
          'succeeded, its contents remain on this device.');
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> _pickFile({bool uploadCloud = false}) async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.custom,
        allowedExtensions: ['json'], withData: true);
      if (result == null || result.files.isEmpty) return;
      final Uint8List? bytes = result.files.single.bytes;
      if (bytes == null) {
        if (mounted) showMessage(context, 'Cannot read selected file.');
        return;
      }
      if (bytes.lengthInBytes > 5 * 1024 * 1024) {
        throw const FormatException('JSON files must be 5 MB or smaller.');
      }
      final jsonText = utf8.decode(bytes);
      if (uploadCloud) {
        await _upload(jsonText);
      } else {
        await _import(jsonText);
      }
    } catch (e) {
      if (mounted) showMessage(context, 'File selection failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = StudyScope.of(context);
    return ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 28), children: [
      const SectionTitle('Quiz library', subtitle: 'Local-first JSON collections. Import packs without deleting progress.'),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.25,
        children: [
          NumberCard('${state.normalQuestions.length}', 'Quiz questions', Icons.quiz_outlined),
          NumberCard('${state.terms.length}', 'Language terms', Icons.language),
        ]),
      const SizedBox(height: 12),
      ElevatedButton.icon(onPressed: importing ? null : () => _pickFile(),
        icon: const Icon(Icons.file_open), label: const Text('Import JSON locally')),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: importing ? null : () => _pickFile(uploadCloud: true),
        icon: const Icon(Icons.cloud_upload_outlined),
        label: const Text('Upload JSON → Supabase + local')),
      const SizedBox(height: 8),
      const Text('Cloud uploads require signing in on the Cloud tab. The original JSON '
        'pack is stored in your Supabase account; answers and review history '
        'stay offline in SQLite.', style: TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 14),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Or paste a JSON pack', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        TextField(controller: controller, maxLines: 8, minLines: 5,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
          decoration: const InputDecoration(hintText: '{ "type": "quiz", "id": "...", ... }')),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: importing ? null : () => _import(controller.text),
          icon: const Icon(Icons.save_alt), label: const Text('Import pasted JSON')),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: importing ? null : () => _upload(controller.text),
          icon: const Icon(Icons.cloud_upload), label: const Text('Upload pasted JSON → Supabase')),
      ])),
      const SectionTitle('Accepted JSON schemas'),
      const Panel(child: SelectableText('''QUIZ PACK
{
 "type": "quiz",
 "id": "my-pack",
 "title": "General knowledge",
 "questions": [
   {"id": "q1", "topic": "Science",
    "prompt": "What is H2O?",
    "options": ["Water", "Oxygen", "Salt"],
    "answerIndex": 0,
    "explanation": "H2O is water."}
 ]
}

LANGUAGE PACK
{
 "type": "language",
 "id": "body",
 "title": "Body parts",
 "terms": [
   {"id": "arm", "topic": "Anatomy",
    "translations": {
      "en": "arm", "es": "brazo",
      "pt": "braço", "it": "braccio"}}
 ]
}

Language multiple-choice sets need >=4 distinct target translations. Codes: en, es, pt, it, fr, de, ru, ja, zh, ko.''',
        style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: muted))),
      const SectionTitle('Mastery policy'),
      const Panel(child: Text('Every item must pass 3 correct answers in week 1, '
        '2 in week 2, and 1 in week 3. Each week is seven days relative to its '
        'first answer. Missing a target resets its three-week cycle. After mastery, '
        'green items are excluded from the priority queue. A wrong answer on a '
        'mastered item restarts that item. Incorrect attempts remain in its history.',
        style: TextStyle(height: 1.5))),
    ]);
  }
}
