import 'package:flutter/material.dart';
import '../domain/language_builder.dart';
import '../domain/review_engine.dart';
import '../main.dart';
import 'quiz_screen.dart';
import 'shared.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  void launch(BuildContext context, bool manual) {
    final state = StudyScope.of(context);
    final questions = state.ordered(state.languageQuestions(), applyFilters: false)
        .where((q) => !state.forQuestion(q).mastered &&
            (!state.languageDueOnly || ReviewEngine.due(state.forQuestion(q), DateTime.now()))).toList();
    if (questions.isEmpty) {
      showMessage(context, 'No due questions. Turn off Due now only, or import at least 4 parallel terms.');
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(
      questions: questions, manual: manual)));
  }

  Widget _selector(BuildContext context, String property, String value, String label) {
    final state = StudyScope.of(context);
    final options = languageNames.entries.toList();
    return DropdownButtonFormField<String>(
      initialValue: languageNames.containsKey(value) ? value : 'en',
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: options.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
      onChanged: (code) async {
        if (code != null) await state.setLanguage(property, code);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = StudyScope.of(context);
    final questions = state.ordered(state.languageQuestions(), applyFilters: false);
    final masteredCount = questions.where((q) => state.forQuestion(q).mastered).length;
    final active = questions.where((q) => !state.forQuestion(q).mastered).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 28), children: [
      const SectionTitle('Languages', subtitle: 'Source words and target answers — independent of question UI language.'),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _selector(context, 'sourceLanguage', state.sourceLanguage, 'Source language (word shown)'),
        const SizedBox(height: 12),
        _selector(context, 'targetLanguage', state.targetLanguage, 'Target language (all answers)'),
        const SizedBox(height: 12),
        _selector(context, 'uiLanguage', state.uiLanguage, 'Question / instruction language'),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          key: ValueKey('category:${state.languageCategoryFilter}'),
          initialValue: state.languageCategoryFilter,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Vocabulary category'),
          items: ['All', ...state.languageCategories].map((category) =>
            DropdownMenuItem(value: category, child: Text(category, overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (value) { if (value != null) state.setLanguageCategory(value); },
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          key: ValueKey('subcategory:${state.languageCategoryFilter}:${state.languageSubtopicFilter}'),
          initialValue: state.languageSubtopicFilter,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Vocabulary subcategory'),
          items: ['All', ...state.languageSubtopics].map((subtopic) =>
            DropdownMenuItem(value: subtopic, child: Text(subtopic, overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (value) { if (value != null) state.setLanguageSubtopic(value); },
        ),
        const SizedBox(height: 14),
        const Text('Default: English question language. Your source word stays in the source language, and every option is in the target language.',
          style: TextStyle(color: muted, fontSize: 12)),
      ])),
      const SectionTitle('Live example'),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('QUESTION LANGUAGE', style: TextStyle(color: cyan, fontSize: 11)),
        const SizedBox(height: 8),
        Text(questions.isEmpty
            ? LanguageBuilder.prompt('brazo', state.targetLanguage, state.uiLanguage)
            : questions.first.prompt,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(questions.isEmpty ? 'Import 4+ terms with translations in both languages.'
            : 'Answers: ${questions.first.options.join(' · ')}',
          style: const TextStyle(color: muted)),
      ])),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: NumberCard('${active.length}', 'To learn', Icons.menu_book)),
        const SizedBox(width: 10),
        Expanded(child: NumberCard('$masteredCount', 'Mastered', Icons.verified, tint: green)),
      ]),
      const SizedBox(height: 14),
      if (state.sourceLanguage == state.targetLanguage)
        const Panel(child: Text('Choose two different languages.')),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: state.languageDueOnly,
        title: const Text('Due now only'),
        subtitle: const Text('Hide scheduled questions until they are due.'),
        onChanged: state.setLanguageDueOnly),
      const SizedBox(height: 8),
      ElevatedButton.icon(onPressed: () => launch(context, false),
        icon: const Icon(Icons.play_arrow), label: const Text('Start automatic language quiz')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => launch(context, true),
        icon: const Icon(Icons.psychology), label: const Text('Start Anki-style language review')),
      const SectionTitle('Language priorities'),
      for (final q in active.take(25)) Padding(padding: const EdgeInsets.only(bottom: 8), child: Panel(
        child: Row(children: [
          Icon(Icons.circle, size: 12, color: trafficColor(ReviewEngine.traffic(state.forQuestion(q)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(q.prompt, maxLines: 2, overflow: TextOverflow.ellipsis),
            Text('${q.topic} • Wrong ${state.forQuestion(q).wrongTotal}×',
                style: const TextStyle(color: muted, fontSize: 12)),
          ])),
        ]),
      )),
    ]);
  }
}
