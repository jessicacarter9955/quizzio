import 'package:flutter/material.dart';
import '../domain/language_builder.dart';
import '../models/quiz_models.dart';
import '../state/study_state.dart';
import '../domain/review_engine.dart';
import '../main.dart';
import 'quiz_screen.dart';
import 'writing_screen.dart';
import 'similarity_screen.dart';
import 'shared.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  void launch(BuildContext context, bool manual) {
    final state = StudyScope.of(context);
    final questions = state.ordered(state.languageQuestions(), applyFilters: false)
        .where((q) => (state.languageTrafficFilter == TrafficLight.green || !state.forQuestion(q).mastered) &&
            (state.languageTrafficFilter == null || ReviewEngine.traffic(state.forQuestion(q)) == state.languageTrafficFilter) &&
            (state.languageTrafficFilter == TrafficLight.green || !state.languageDueOnly || ReviewEngine.due(state.forQuestion(q), DateTime.now()))).toList();
    if (questions.isEmpty) {
      showMessage(context, 'No due questions. Turn off Due now only, or import at least 4 parallel terms.');
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(
      questions: questions.take(state.quizSize).toList(), manual: manual)));
  }

  void launchWriting(BuildContext context) {
    final state=StudyScope.of(context);
    final items=state.filteredLanguageTerms.where((term) =>
      state.vocabularySelected(term) &&
      (term.translations[state.sourceLanguage]?.isNotEmpty ?? false) &&
      (term.translations[state.targetLanguage]?.isNotEmpty ?? false)) .toList();
    final byId={for(final q in state.allLanguageQuestions()) q.id:q};
    items.sort((a,b) {
      final qa=byId[state.vocabularyId(a)];
      final qb=byId[state.vocabularyId(b)];
      final wa=qa==null?0:state.forQuestion(qa).wrongTotal;
      final wb=qb==null?0:state.forQuestion(qb).wrongTotal;
      return wb.compareTo(wa);
    });
    if (items.isEmpty) {showMessage(context,'Select words or phrases for this language direction.');return;}
    Navigator.push(context, MaterialPageRoute(builder: (_)=>WritingScreen(items: items.take(state.quizSize).toList())));
  }

  Widget _selector(BuildContext context, String property, String value, String label) {
    final state = StudyScope.of(context);
    final options = languageNames.entries.where((item) {
      if (property == 'targetLanguage' && item.key == state.sourceLanguage) return false;
      if (property == 'sourceLanguage' && item.key == state.targetLanguage) return false;
      if (property == 'uiLanguage') return true;
      return state.terms.any((term)=>state.contentMatches(term) &&
          (term.translations[item.key]?.isNotEmpty ?? false) &&
          (term.translations[property=='sourceLanguage' ? state.targetLanguage : state.sourceLanguage]?.isNotEmpty ?? false));
    }).toList();
    return DropdownButtonFormField<String>(
      key: ValueKey('$property:$value:${state.languageContentFilter}'),
      initialValue: options.any((e)=>e.key==value) ? value : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: options.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
      onChanged: (code) async {
        if (code != null) await state.setLanguage(property, code);
      },
    );
  }

  Widget _groupSummary(VocabularyGroupStats stats) =>
      Text('${stats.selected}/${stats.total} selected · ${stats.available} quiz-ready · ${stats.mastered} mastered\n'
          '🔴 ${stats.red}  🟡 ${stats.yellow}  🟢 ${stats.green}  · ${stats.due} due · ${stats.accuracy} accuracy (${stats.attempts} answers)',
          style: const TextStyle(color: muted, fontSize: 11));

  Widget _vocabularyTree(BuildContext context, StudyState state,
      Map<String, QuizQuestion> byId) {
    final byCategory = <String, List<LanguageTerm>>{};
    for (final term in state.filteredLanguageTerms) {
      byCategory.putIfAbsent(StudyState.getCategory(term), () => []).add(term);
    }
    final categories = byCategory.keys.toList()..sort();
    return Column(children: [
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(state.languageContentFilter == 'phrases' ? 'Phrasebook selection' : 'Vocabulary selection',
          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Checkbox states: checked = all words; dash = some; empty = none. Tap a category to browse its subcategories.',
          style: TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 10),
        Row(children: [
          OutlinedButton(onPressed: () => state.setVocabularySelection(state.filteredLanguageTerms, true),
            child: const Text('Select all')),
          const SizedBox(width: 8),
          OutlinedButton(onPressed: () => state.setVocabularySelection(state.filteredLanguageTerms, false),
            child: const Text('Clear all')),
        ]),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          key: ValueKey('languageTrafficFilter:${state.languageTrafficFilter}'),
          initialValue: state.languageTrafficFilter?.name ?? 'all',
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Quiz by traffic light'),
          items: const [
            DropdownMenuItem(value: 'all', child: Text('All learning statuses')),
            DropdownMenuItem(value: 'red', child: Text('🔴 Needs work')),
            DropdownMenuItem(value: 'yellow', child: Text('🟡 Learning')),
            DropdownMenuItem(value: 'green', child: Text('🟢 Mastered')),
          ],
          onChanged: (v) => state.setLanguageTraffic(v == 'all' ? null :
            TrafficLight.values.firstWhere((t) => t.name == v)),
        ),
      ])),
      const SizedBox(height: 8),
      for (final category in categories) ...[
        Builder(builder: (context) {
          final categoryTerms = byCategory[category]!;
          final summary = state.vocabularyStats(categoryTerms, byId);
          final bySub = <String, List<LanguageTerm>>{};
          for (final term in categoryTerms) {
            bySub.putIfAbsent(StudyState.getSubtopic(term), () => []).add(term);
          }
          final subcategories = bySub.keys.toList()..sort();
          return Panel(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            child: ExpansionTile(
              key: PageStorageKey('category:$category'),
              leading: Checkbox(tristate: true,
                value: state.vocabularyGroupSelection(categoryTerms),
                onChanged: (_) => state.setVocabularySelection(categoryTerms,
                  state.vocabularyGroupSelection(categoryTerms) != true)),
              title: Text(category, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: _groupSummary(summary),
              children: [
                for (final sub in subcategories) Builder(builder: (context) {
                  final group = bySub[sub]!;
                  return Padding(padding: const EdgeInsets.only(left: 8),
                    child: ExpansionTile(
                      key: PageStorageKey('category:$category/sub:$sub'),
                      leading: Checkbox(tristate: true,
                        value: state.vocabularyGroupSelection(group),
                        onChanged: (_) => state.setVocabularySelection(group,
                          state.vocabularyGroupSelection(group) != true)),
                      title: Text(sub),
                      subtitle: _groupSummary(state.vocabularyStats(group, byId)),
                      children: [
                        for (final term in group) Builder(builder: (context) {
                          final question = byId[state.vocabularyId(term)];
                          final source = term.translations[state.sourceLanguage] ?? '—';
                          final target = term.translations[state.targetLanguage] ?? '—';
                          final status = question == null ? null :
                              ReviewEngine.traffic(state.forQuestion(question));
                          return CheckboxListTile(
                            dense: true,
                            visualDensity: VisualDensity.compact,
                            value: state.vocabularySelected(term),
                            onChanged: (v) => state.setVocabularySelection([term], v ?? false),
                            title: Text('$source → $target', maxLines: 2,
                              overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                            subtitle: question == null ? const Text('Not quiz-ready for this language pair',
                              style: TextStyle(fontSize: 10, color: muted)) :
                              Text('Correct ${state.forQuestion(question).correctTotal} · Wrong ${state.forQuestion(question).wrongTotal}',
                                style: const TextStyle(fontSize: 10, color: muted)),
                            secondary: Icon(Icons.circle, size: 12,
                              color: status == null ? muted : trafficColor(status)),
                          );
                        }),
                      ],
                    ));
                }),
              ],
            ));
        }),
        const SizedBox(height: 8),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final state = StudyScope.of(context);
    final questions = state.ordered(state.languageQuestions(), applyFilters: false);
    final allQuestions = state.allLanguageQuestions();
    final byId = {for (final q in allQuestions) q.id: q};
    final allStats = state.vocabularyStats(state.filteredLanguageTerms, byId);
    final wordStats = state.vocabularyStats(state.terms.where((t) => t.kind != 'phrase'), byId);
    final phraseStats = state.vocabularyStats(state.terms.where((t) => t.kind == 'phrase'), byId);
    final masteredCount = questions.where((q) => state.forQuestion(q).mastered).length;
    final active = questions.where((q) => !state.forQuestion(q).mastered).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 28), children: [
      const SectionTitle('Languages', subtitle: 'Source words and target answers — independent of question UI language.'),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _selector(context, 'sourceLanguage', state.sourceLanguage, 'Source language (word shown)'),
        const SizedBox(height: 12),
        _selector(context, 'targetLanguage', state.targetLanguage, 'Target language (all answers)'),
        const SizedBox(height: 12),
        _selector(context, 'uiLanguage', state.uiLanguage, 'Question / instruction language'),
        const SizedBox(height: 12),
        const Text('Select whole categories, subcategories, or individual words below.',
          style: TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 12),
        const Text('Default: English question language. Your source word stays in the source language, and every option is in the target language.',
          style: TextStyle(color: muted, fontSize: 12)),
      ])),
      const SectionTitle('Study material', subtitle: 'Words and complete phrases have separate rankings and category statistics.'),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Vocabulary: ${wordStats.total} items · ${wordStats.mastered} mastered · ${wordStats.accuracy} accuracy'),
        const SizedBox(height: 5),
        Text('Phrasebook: ${phraseStats.total} phrases · ${phraseStats.mastered} mastered · ${phraseStats.accuracy} accuracy'),
        const SizedBox(height: 10),
        Wrap(spacing: 6, children: [
          for (final mode in const [('words', 'Vocabulary'), ('phrases', 'Phrasebook')])
            ChoiceChip(label: Text(mode.$2),
              selected: state.languageContentFilter == mode.$1,
              onSelected: (_) => state.setLanguageContentFilter(mode.$1)),
        ]),
      ])),
      const SectionTitle('Study tree', subtitle: 'Category → Subcategory → individual words or complete phrases.'),
      Panel(child: _groupSummary(allStats)),
      const SizedBox(height: 8),
      ExpansionTile(key: const PageStorageKey('vocabulary-tree-root'),
        title: Text(state.languageContentFilter == 'phrases' ? 'Browse & select phrases' : 'Browse & select vocabulary',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${allStats.selected} / ${allStats.total} items selected · ${allStats.available} quiz-ready',
          style: const TextStyle(color: muted, fontSize: 12)),
        children: [_vocabularyTree(context, state, byId)]),
      const SectionTitle('Live example'),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('QUESTION LANGUAGE', style: TextStyle(color: cyan, fontSize: 11)),
        const SizedBox(height: 8),
        Text(questions.isEmpty
            ? LanguageBuilder.prompt('brazo', state.targetLanguage, state.uiLanguage)
            : questions.first.prompt,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(questions.isEmpty ? 'Import 4+ terms with translations in both languages.'
            : 'Answers: ${questions.first.options.join(' · ')}',
          style: const TextStyle(color: muted)),
      ])),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: NumberCard('${active.length}', 'To learn', Icons.menu_book)),
        const SizedBox(width: 10),
        Expanded(child: NumberCard('$masteredCount', 'Mastered', Icons.verified, tint: green)),
      ]),
      const SizedBox(height: 14),
      if (state.sourceLanguage == state.targetLanguage)
        const Panel(child: Text('Choose two different languages.')),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: state.languageDueOnly,
        title: const Text('Due now only'),
        subtitle: const Text('Hide scheduled questions until they are due.'),
        onChanged: state.setLanguageDueOnly),
      const SectionTitle('Game modes', subtitle: 'Multiple-choice, writing, and manual similarity colors are separate activities.'),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Questions per round', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final count in [5,10,20,30,50,100]) ChoiceChip(label: Text('$count'),
            selected: state.quizSize==count, onSelected: (_)=>state.setQuizSize(count)),
        ]),
        const SizedBox(height: 8),
        Text('Up to ${state.quizSize} distinct questions, from your current selected ${state.languageContentFilter}.',
          style: const TextStyle(color: muted,fontSize: 12)),
      ])),
      const SizedBox(height: 8),
      ElevatedButton.icon(onPressed: () => launch(context, false),
        icon: const Icon(Icons.videogame_asset), label: const Text('Play multiple-choice quiz')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => launch(context, true),
        icon: const Icon(Icons.psychology), label: const Text('Play Anki-style review')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => launchWriting(context),
        icon: const Icon(Icons.edit), label: const Text('Write the missing translation')),
      const SizedBox(height: 8),
      if (state.languageContentFilter=='words') OutlinedButton.icon(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_)=>const SimilarityScreen())),
        icon: const Icon(Icons.palette), label: const Text('Manual similarity colors (3 + neutral)')),
      const SizedBox(height: 10),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Writing statistics (${state.languageContentFilter} · ${state.sourceLanguage} → ${state.targetLanguage})',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('Attempts: ${state.currentWritingAttempts.length} · '
          'correct: ${state.currentWritingAttempts.where((x)=>x['outcome']=='correct').length} · '
          'wrong: ${state.currentWritingAttempts.where((x)=>x['outcome']=='wrong').length} · '
          'revealed: ${state.currentWritingAttempts.where((x)=>x['outcome']=='revealed').length}',
          style: const TextStyle(fontSize: 12,color: muted)),
      ])),
      const SectionTitle('Language priorities', subtitle: 'Selected words ranked by most missed.'),
      for (final q in active.take(25)) Padding(padding: const EdgeInsets.only(bottom: 8), child: Panel(
        child: Row(children: [
          Icon(Icons.circle, size: 12, color: trafficColor(ReviewEngine.traffic(state.forQuestion(q)))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(q.prompt, maxLines: 2, overflow: TextOverflow.ellipsis),
            Text('${q.topic} • Wrong ${state.forQuestion(q).wrongTotal}×',
                style: const TextStyle(color: muted, fontSize: 12)),
          ])),
        ]),
      )),
    ]);
  }
}
