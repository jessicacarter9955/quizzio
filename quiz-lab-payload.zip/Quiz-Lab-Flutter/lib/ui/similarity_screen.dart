import 'package:flutter/material.dart';
import '../main.dart';
import '../state/study_state.dart';
import '../models/quiz_models.dart';
import 'shared.dart';

/// Purely manual similarity labels. These are *not* the quiz mastery colors.
class SimilarityScreen extends StatefulWidget {
  const SimilarityScreen({super.key});
  @override
  State<SimilarityScreen> createState() => _SimilarityScreenState();
}

class _SimilarityScreenState extends State<SimilarityScreen> {
  String search = '';
  bool onlyUnclassified = false;
  String category = 'All';

  @override
  Widget build(BuildContext context) {
    final state = StudyScope.of(context);
    final all = state.terms.where((t) => t.kind != 'phrase' &&
      (t.translations[state.sourceLanguage]?.isNotEmpty ?? false) &&
      (t.translations[state.targetLanguage]?.isNotEmpty ?? false)).toList();
    final categories = <String>{for (final t in all) StudyState.getCategory(t)}.toList()..sort();
    if (category != 'All' && !categories.contains(category)) category = 'All';
    final filtered = all.where((t) {
      if (category != 'All' && StudyState.getCategory(t) != category) return false;
      if (onlyUnclassified && state.manualColor(t) != 'neutral') return false;
      final haystack = '${StudyState.getCategory(t)} ${StudyState.getSubtopic(t)} '
          '${t.translations[state.sourceLanguage]} ${t.translations[state.targetLanguage]}'.toLowerCase();
      return haystack.contains(search.toLowerCase().trim());
    }).toList();
    final groups = <String, int>{for (final k in ['green', 'yellow', 'red', 'neutral']) k: 0};
    for (final t in all) { final k=state.manualColor(t); groups[k]=(groups[k]??0)+1; }
    const values = [
      ('green', 'Very similar', Icons.check_circle, Color(0xff46d59c)),
      ('yellow', 'Similar', Icons.remove_circle, Color(0xffffca6e)),
      ('red', 'Different', Icons.cancel, Color(0xfffa7686)),
      ('neutral', 'Neutral', Icons.radio_button_unchecked, Color(0xff9db0c6)),
    ];
    return Scaffold(appBar: AppBar(title: const Text('Similarity traffic lights')),
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Classify how alike translations feel to you. These labels never change quiz mastery.',
              style: TextStyle(color: muted, fontSize: 12)),
          const SizedBox(height: 10),
          Text('${state.sourceLanguage.toUpperCase()} ↔ ${state.targetLanguage.toUpperCase()} · ${all.length} words',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final item in values) Chip(avatar: CircleAvatar(backgroundColor: item.$4, radius: 6),
              label: Text('${groups[item.$1]} ${item.$2}', style: const TextStyle(fontSize: 11))),
          ]),
          TextField(decoration: const InputDecoration(labelText: 'Find a word or topic', prefixIcon: Icon(Icons.search)),
            onChanged: (v) => setState(() => search = v)),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(initialValue: category, isExpanded: true,
            decoration: const InputDecoration(labelText: 'Category'),
            items: ['All', ...categories].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) => setState(() => category = v ?? 'All')),
          CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Only unclassified words'), value: onlyUnclassified,
            onChanged: (v) => setState(() => onlyUnclassified = v ?? false)),
          Text('${filtered.length} words shown', style: const TextStyle(fontSize: 12, color: muted)),
        ])),
        Expanded(child: ListView.builder(itemCount: filtered.length, itemBuilder: (context, index) {
          final LanguageTerm term = filtered[index];
          final choice=state.manualColor(term);
          return Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
            child: Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${term.translations[state.sourceLanguage]} → ${term.translations[state.targetLanguage]}',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              Text('${StudyState.getCategory(term)} / ${StudyState.getSubtopic(term)}',
                  style: const TextStyle(fontSize: 11, color: muted)),
              const SizedBox(height: 8),
              Row(children: [for (final item in values) Expanded(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: Tooltip(message: item.$2, child: IconButton.filledTonal(
                  onPressed: () => state.setManualColor(term, item.$1),
                  style: IconButton.styleFrom(backgroundColor: choice == item.$1
                      ? item.$4.withValues(alpha: .34) : deepBlue,
                    side: choice == item.$1 ? BorderSide(color: item.$4, width: 2) : BorderSide.none),
                  icon: Icon(item.$3, color: item.$4),
                )),
              ))]),
            ])));
        })),
      ])),
    );
  }
}
