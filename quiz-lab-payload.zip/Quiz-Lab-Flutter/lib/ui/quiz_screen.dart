import 'dart:async';
import 'package:flutter/material.dart';
import '../domain/review_engine.dart';
import '../main.dart';
import '../models/quiz_models.dart';
import 'shared.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.questions, required this.manual});
  final List<QuizQuestion> questions;
  final bool manual;
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int index = 0;
  int? selected;
  int remaining = 60;
  int correct = 0;
  int attempted = 0;
  bool saved = false;
  bool busy = false;
  bool finished = false;
  Timer? timer;
  late DateTime startedAt;

  QuizQuestion get current => widget.questions[index];

  @override
  void initState() {
    super.initState();
    _startQuestion();
  }

  void _startQuestion() {
    startedAt = DateTime.now();
    remaining = 60;
    selected = null;
    saved = false;
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || saved || busy || selected != null) return;
      if (remaining <= 1) {
        timer?.cancel();
        _save(ReviewRating.again, timedOut: true);
      } else {
        setState(() => remaining--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _select(int value) async {
    if (selected != null || busy || saved) return;
    timer?.cancel();
    setState(() => selected = value);
    if (!widget.manual) {
      await _save(value == current.answerIndex ? ReviewRating.good : ReviewRating.again);
    }
  }

  Future<void> _save(ReviewRating rating, {bool timedOut = false}) async {
    if (saved || busy) return;
    setState(() => busy = true);
    final isCorrect = selected != null && selected == current.answerIndex;
    try {
      await StudyScope.of(context).answer(current,
        correct: isCorrect,
        rating: isCorrect ? rating : ReviewRating.again,
        elapsedMs: DateTime.now().difference(startedAt).inMilliseconds.clamp(0, 60000).toInt(),
      );
      if (!mounted) return;
      setState(() {
        saved = true;
        busy = false;
        attempted++;
        if (isCorrect) correct++;
      });
      if (timedOut) showMessage(context, 'Time expired — recorded as incorrect.');
    } catch (e) {
      if (!mounted) return;
      setState(() => busy = false);
      showMessage(context, 'Unable to save answer: $e');
    }
  }

  Future<void> _skip() async {
    if (busy) return;
    if (!saved) await _save(ReviewRating.again);
    if (saved) _next();
  }

  void _next() {
    if (busy || !saved) return;
    if (index + 1 == widget.questions.length) {
      setState(() => finished = true);
    } else {
      setState(() => index++);
      _startQuestion();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (finished) return Scaffold(
      appBar: AppBar(title: const Text('Session finished')),
      body: Center(child: Padding(padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.emoji_events_outlined, color: cyan, size: 76),
          const SizedBox(height: 16),
          const Text('Session complete', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('$correct / $attempted correct', style: const TextStyle(fontSize: 22, color: muted)),
          const SizedBox(height: 8),
          const Text('Every answer has been saved to your progress and statistics.', textAlign: TextAlign.center),
          const SizedBox(height: 22),
          ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Back to dashboard')),
        ]))),
    );

    final question = current;
    final p = StudyScope.of(context).forQuestion(question);
    final answeredCorrectly = selected == question.answerIndex;
    return Scaffold(
      appBar: AppBar(title: Text(widget.manual ? 'Anki-style review' : 'Automatic quiz'), actions: [
        TextButton(onPressed: busy ? null : _skip, child: const Text('Skip')),
      ]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Question ${index + 1}/${widget.questions.length}', style: const TextStyle(fontSize: 17, color: muted)),
          Row(children: [const Icon(Icons.timer_outlined, size: 19, color: cyan),
            const SizedBox(width: 6), Text('${remaining}s', style: const TextStyle(fontWeight: FontWeight.bold))]),
        ]),
        const SizedBox(height: 12),
        ClipRRect(borderRadius: BorderRadius.circular(30),
          child: LinearProgressIndicator(value: (index + 1) / widget.questions.length,
            minHeight: 10, backgroundColor: deepBlue)),
        const SizedBox(height: 18),
        Wrap(spacing: 8, runSpacing: 8, children: [
          TrafficPill(traffic: ReviewEngine.traffic(p)),
          Chip(label: Text(question.topic, style: const TextStyle(fontSize: 12))),
          if (p.wrongTotal > 0) Chip(label: Text('Wrong ${p.wrongTotal}×')),
        ]),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(question.prompt, style: const TextStyle(color: ink, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 20),
            for (var i = 0; i < question.options.length; i++) ...[
              _answerOption(question, i),
              const SizedBox(height: 10),
            ],
            if (selected != null || saved) ...[
              const SizedBox(height: 16),
              Text(question.explanation.isNotEmpty
                ? question.explanation
                : 'Correct answer: ${question.options[question.answerIndex]}',
                style: const TextStyle(color: ink)),
            ],
          ]),
        ),
        const SizedBox(height: 18),
        if (busy) const Center(child: CircularProgressIndicator()),
        if (selected != null && !saved && !busy && widget.manual) ...[
          Text(answeredCorrectly
              ? 'How well did you recall it?'
              : 'Incorrect answers are always scheduled as Again.',
              style: const TextStyle(color: muted)),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final rating in ReviewRating.values)
              OutlinedButton(
                onPressed: () async {
                  await _save(rating);
                  if (mounted && saved) _next();
                },
                child: Text(rating.name.toUpperCase()),
              ),
          ]),
        ],
        if (saved && !busy) SizedBox(width: double.infinity, child: ElevatedButton(
          onPressed: _next,
          child: Text(index + 1 == widget.questions.length ? 'Finish' : 'Next question'),
        )),
        const SizedBox(height: 16),
        const Text('Priority: questions with the most incorrect attempts come first.',
          textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12)),
      ])),
    );
  }

  Widget _answerOption(QuizQuestion question, int i) {
    final reveal = selected != null || saved;
    final isRight = reveal && i == question.answerIndex;
    final isWrong = selected == i && i != question.answerIndex;
    final color = isRight ? green : isWrong ? red : const Color(0xffccd5e3);
    return InkWell(
      onTap: () => _select(i),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          border: Border.all(color: color, width: (isRight || isWrong) ? 2 : 1),
          borderRadius: BorderRadius.circular(14),
          color: (isRight || isWrong) ? color.withValues(alpha: .12) : Colors.transparent,
        ),
        child: Row(children: [
          Container(width: 28, height: 28, alignment: Alignment.center,
            decoration: BoxDecoration(color: color.withValues(alpha: .25), shape: BoxShape.circle),
            child: Text('${i + 1}', style: const TextStyle(color: ink, fontWeight: FontWeight.bold))),
          const SizedBox(width: 12),
          Expanded(child: Text(question.options[i],
            style: const TextStyle(fontSize: 16, color: ink))),
          if (isRight) const Icon(Icons.check_circle, color: green),
          if (isWrong) const Icon(Icons.cancel, color: red),
        ]),
      ),
    );
  }
}
