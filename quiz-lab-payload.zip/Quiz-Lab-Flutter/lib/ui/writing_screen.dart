import 'package:flutter/material.dart';
import '../main.dart';
import '../models/quiz_models.dart';
import '../state/study_state.dart';
import 'shared.dart';

/// Writing attempts are stored separately from QuizQuestion/ReviewProgress.
class WritingScreen extends StatefulWidget {
  const WritingScreen({super.key, required this.items});
  final List<LanguageTerm> items;
  @override
  State<WritingScreen> createState() => _WritingScreenState();
}

class _WritingScreenState extends State<WritingScreen> {
  final controller = TextEditingController();
  int index = 0, correct = 0, wrong = 0, revealed = 0;
  bool hint = false, busy = false;
  String? result;

  @override
  void dispose() { controller.dispose();super.dispose(); }
  String mask(String text) => text.split(' ').map((part) {
    final chars = part.runes.map(String.fromCharCode).toList();
    if (hint && chars.length > 2) return '${chars.first}${List.filled(chars.length-2, '＿').join()}${chars.last}';
    return List.filled(chars.length < 3 ? 3 : chars.length, '＿').join();
  }).join(' ');

  Future<void> finishAttempt(String outcome) async {
    if (result != null || busy) return;
    setState(() { busy = true;result = outcome; });
    try {
      await StudyScope.of(context).saveWritingAttempt(widget.items[index], outcome, hinted: hint);
      if (!mounted) return;
      setState(() { busy = false;
        if (outcome == 'correct') correct++;
        if (outcome == 'wrong') wrong++;
        if (outcome == 'revealed') revealed++;
      });
    } catch (e) { if (!mounted) return;setState(() {result=null;busy=false;});showMessage(context,'Unable to save writing attempt: $e'); }
  }

  Future<void> check() async {
    final value=controller.text.trim().replaceAll(RegExp(r'\s+'), ' ').toLowerCase();
    if (value.isEmpty) return;
    final state=StudyScope.of(context);
    final expected=widget.items[index].translations[state.targetLanguage]!.trim().replaceAll(RegExp(r'\s+'),' ').toLowerCase();
    await finishAttempt(value==expected?'correct':'wrong');
  }

  void next(){
    setState(() {index++; hint=false;result=null;controller.clear();});
  }

  @override
  Widget build(BuildContext context) {
    final state=StudyScope.of(context);
    if (index >= widget.items.length) return Scaffold(appBar: AppBar(title: const Text('Writing results')),
      body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.emoji_events, size: 72, color: cyan),
        const Text('Writing round complete!', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text('$correct correct · $wrong wrong · $revealed revealed', textAlign: TextAlign.center),
        const SizedBox(height: 8),
        const Text('Saved to writing statistics only. Multiple-choice mastery is unchanged.', textAlign: TextAlign.center, style: TextStyle(color: muted)),
        const SizedBox(height: 25),
        ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Back to Languages')),
      ]))));
    final item=widget.items[index];
    final source=item.translations[state.sourceLanguage]??'';
    final answer=item.translations[state.targetLanguage]??'';
    return Scaffold(appBar: AppBar(title: const Text('Write the translation')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Round ${index+1}/${widget.items.length}',style: const TextStyle(fontWeight: FontWeight.bold)),
          Text('✓ $correct   ✕ $wrong',style: const TextStyle(color: cyan)),
        ]),
        const SizedBox(height: 10),
        LinearProgressIndicator(value: (index+1)/widget.items.length, minHeight: 9),
        const SizedBox(height: 16),
        Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${StudyState.getCategory(item)} / ${StudyState.getSubtopic(item)}',style: const TextStyle(fontSize: 12,color: muted)),
          const SizedBox(height: 12),
          Text(source, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          Text('Translate into ${state.targetLanguage.toUpperCase()}',style: const TextStyle(color: muted)),
          const SizedBox(height: 16),
          Text(mask(answer), style: const TextStyle(fontSize: 22,letterSpacing: 2,color: cyan)),
          const SizedBox(height: 12),
          TextField(controller: controller,enabled:result==null,autofocus:true,
            decoration: const InputDecoration(labelText: 'Type the word or phrase'),
            textInputAction: TextInputAction.done,onSubmitted: (_)=>check()),
          const SizedBox(height: 13),
          if (result == null) ...[
            ElevatedButton(onPressed: busy ? null : check, child: const Text('Check answer')),
            Row(children: [
              Expanded(child: TextButton(onPressed: () => setState(() => hint = true),
                child: const Text('First + last letters'))),
              Expanded(child: TextButton(onPressed: busy?null:()=>finishAttempt('revealed'),
                child: const Text('Reveal & skip'))),
            ]),
          ] else ...[
            Text(result=='correct'?'✓ Correct':result=='revealed'?'↪ Revealed, not counted correct':'✕ Keep practicing',
              style: TextStyle(fontWeight: FontWeight.bold,color:result=='correct'?green:yellow)),
            const SizedBox(height: 8),
            Text(answer,style: const TextStyle(fontSize: 23,color: cyan,fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            ElevatedButton(onPressed: busy?null:next,child: Text(index+1==widget.items.length?'See results':'Next question →')),
          ]
        ])),
        const SizedBox(height: 15),
        const Text('Writing progress is tracked independently of your multiple-choice 3–2–1 review.',
          style: TextStyle(color: muted,fontSize: 12)),
      ])));
  }
}
