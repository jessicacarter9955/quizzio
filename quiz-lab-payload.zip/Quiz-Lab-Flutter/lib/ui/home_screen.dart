import 'package:flutter/material.dart';
import '../domain/review_engine.dart';
import '../main.dart';
import '../models/quiz_models.dart';
import 'bank_screen.dart';
import 'cloud_screen.dart';
import 'language_screen.dart';
import 'quiz_screen.dart';
import 'shared.dart';
import 'stats_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final screens = [const StudyTab(), const LanguageScreen(),
      const StatsScreen(), const BankScreen(), const CloudScreen()];
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Container(padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(color: cyan, borderRadius: BorderRadius.circular(11)),
          child: const Icon(Icons.auto_stories_rounded, color: ink, size: 21)),
        const SizedBox(width: 12),
        const Text('QUIZ LAB', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.6)),
      ])),
      body: IndexedStack(index: tab, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        backgroundColor: deepBlue, indicatorColor: cyan.withValues(alpha: .2),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'Study'),
          NavigationDestination(icon: Icon(Icons.translate), label: 'Languages'),
          NavigationDestination(icon: Icon(Icons.analytics_outlined), label: 'Statistics'),
          NavigationDestination(icon: Icon(Icons.library_books_outlined), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.cloud_outlined), label: 'Cloud'),
        ],
      ),
    );
  }
}

class StudyTab extends StatelessWidget {
  const StudyTab({super.key});

  void launch(BuildContext context, List<QuizQuestion> questions, bool manual) {
    if (questions.isEmpty) {
      showMessage(context, 'No questions match these filters.');
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(
      questions: questions, manual: manual)));
  }

  @override
  Widget build(BuildContext context) {
    final state = StudyScope.of(context);
    final now = DateTime.now();
    final questions = state.ordered(state.normalQuestions);
    final newCount = state.normalQuestions.where((q) => !state.progress.containsKey(q.itemKey)).length;
    final dueCount = state.normalQuestions.where((q) => ReviewEngine.due(state.forQuestion(q), now)).length;
    final wrongCount = state.normalQuestions.where((q) => state.forQuestion(q).wrongTotal > 0 &&
        !state.forQuestion(q).mastered).length;
    final masteredCount = state.normalQuestions.where((q) => state.forQuestion(q).mastered).length;

    return ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 28), children: [
      const SectionTitle('Your learning queue', subtitle: 'Most frequently missed questions are ranked first.'),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
        childAspectRatio: 1.25, children: [
          NumberCard('$dueCount', 'Due or new', Icons.event_available),
          NumberCard('$wrongCount', 'Missed before', Icons.priority_high, tint: red),
          NumberCard('$newCount', 'New questions', Icons.add_circle_outline, tint: yellow),
          NumberCard('$masteredCount', 'Mastered', Icons.verified_outlined, tint: green),
        ]),
      const SizedBox(height: 16),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('START A SESSION', style: TextStyle(color: muted, fontSize: 12, letterSpacing: 1)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: ElevatedButton.icon(
            onPressed: () => launch(context, questions, false),
            icon: const Icon(Icons.bolt), label: const Text('Automatic'))),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(
            onPressed: () => launch(context, questions, true),
            icon: const Icon(Icons.psychology_outlined), label: const Text('Anki-style'))),
        ]),
        const SizedBox(height: 8),
        const Text('Automatic rates correct/incorrect. Anki-style adds Again / Hard / Good / Easy.',
          style: TextStyle(color: muted, fontSize: 12)),
      ])),
      const SectionTitle('Filters & priority'),
      SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
        ChoiceChip(label: const Text('All'), selected: state.trafficFilter == null,
          onSelected: (_) => state.setFilters(clearTraffic: true)),
        const SizedBox(width: 8),
        for (final light in TrafficLight.values) ...[
          ChoiceChip(label: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.circle, size: 10, color: trafficColor(light)),
            const SizedBox(width: 6), Text(trafficName(light)),
          ]), selected: state.trafficFilter == light,
            onSelected: (_) => state.setFilters(traffic: light)),
          const SizedBox(width: 8),
        ],
      ])),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: DropdownButtonFormField<String>(
          initialValue: state.topicFilter,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Topic'),
          items: ['All', ...state.topics].map((t) => DropdownMenuItem(value: t,
            child: Text(t, overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (value) { if (value != null) state.setFilters(topic: value); },
        )),
      ]),
      SwitchListTile(contentPadding: EdgeInsets.zero,
        value: state.showOnlyDue, title: const Text('Due now only'),
        onChanged: (v) => state.setFilters(onlyDue: v)),
      SwitchListTile(contentPadding: EdgeInsets.zero,
        value: state.includeMastered, title: const Text('Include mastered (green)'),
        onChanged: (v) => state.setFilters(mastered: v)),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('${questions.length} questions', style: const TextStyle(color: muted)),
        const Text('SORTED: WRONG ↓', style: TextStyle(color: cyan, fontSize: 12, fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 8),
      for (final q in questions) _QuestionTile(question: q),
      if (questions.isEmpty) const Panel(child: Text('Nothing here. Try clearing filters or import a quiz pack.')),
    ]);
  }
}

class _QuestionTile extends StatelessWidget {
  const _QuestionTile({required this.question});
  final QuizQuestion question;
  @override
  Widget build(BuildContext context) {
    final state = StudyScope.of(context);
    final p = state.forQuestion(question);
    final light = ReviewEngine.traffic(p);
    final wk = ReviewEngine.weekIndex(p, DateTime.now());
    final progress = p.mastered ? '3/3 • 2/2 • 1/1 ✓' :
      p.cycleStart == null ? 'Not started' :
      wk > 2 ? 'Cycle due for restart' :
      'Week ${wk + 1}: ${ReviewEngine.correctThisWeek(p, DateTime.now())}/${ReviewEngine.requiredThisWeek(p, DateTime.now())} correct';
    return Padding(padding: const EdgeInsets.only(bottom: 9), child: Panel(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Container(width: 5, height: 67, decoration: BoxDecoration(
          color: trafficColor(light), borderRadius: BorderRadius.circular(4))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(question.topic, style: const TextStyle(color: muted, fontSize: 11)),
          Text(question.prompt, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 5),
          Text('$progress • Wrong ${p.wrongTotal}×',
              style: TextStyle(fontSize: 12, color: trafficColor(light))),
        ])),
        Icon(ReviewEngine.due(p, DateTime.now()) ? Icons.notifications_active_outlined
            : Icons.schedule, size: 18, color: muted),
      ]),
    ));
  }
}
