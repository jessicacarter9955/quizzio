import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../domain/review_engine.dart';
import '../models/quiz_models.dart';

class StudyDatabase {
  StudyDatabase._();
  static final StudyDatabase instance = StudyDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final dbPath = await getDatabasesPath();
    _database = await openDatabase(p.join(dbPath, 'quiz_learning_v2.db'),
        version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE questions (
        id TEXT PRIMARY KEY, raw_id TEXT NOT NULL, pack_id TEXT NOT NULL,
        topic TEXT NOT NULL, prompt TEXT NOT NULL, options_json TEXT NOT NULL,
        answer_index INTEGER NOT NULL, explanation TEXT NOT NULL
      )''');
      await db.execute('''CREATE TABLE language_terms (
        id TEXT PRIMARY KEY, raw_id TEXT NOT NULL, pack_id TEXT NOT NULL,
        topic TEXT NOT NULL, translations_json TEXT NOT NULL
      )''');
      await db.execute('''CREATE TABLE progress (
        item_id TEXT PRIMARY KEY, cycle_start TEXT,
        week1 INTEGER NOT NULL DEFAULT 0, week2 INTEGER NOT NULL DEFAULT 0,
        week3 INTEGER NOT NULL DEFAULT 0, correct_total INTEGER NOT NULL DEFAULT 0,
        wrong_total INTEGER NOT NULL DEFAULT 0, wrong_streak INTEGER NOT NULL DEFAULT 0,
        mastered INTEGER NOT NULL DEFAULT 0, next_due TEXT, last_answered TEXT
      )''');
      await db.execute('''CREATE TABLE attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT NOT NULL,
        topic TEXT NOT NULL, category TEXT NOT NULL,
        source_lang TEXT NOT NULL, target_lang TEXT NOT NULL,
        correct INTEGER NOT NULL, rating TEXT NOT NULL,
        answered_at TEXT NOT NULL, elapsed_ms INTEGER NOT NULL
      )''');
      await db.execute('CREATE INDEX attempts_by_day ON attempts(answered_at)');
      await db.execute('CREATE INDEX attempts_by_item ON attempts(item_id)');
      await db.execute('CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
    });
    return _database!;
  }

  Future<void> ensureStarterData() async {
    final db = await database;
    final existing = await db.query('settings', where: 'key=?', whereArgs: ['seeded']);
    if (existing.isEmpty) {
      for (final path in ['assets/data/starter_quiz.json', 'assets/data/starter_languages.json']) {
        final data = await rootBundle.loadString(path);
        await importJson(data);
      }
      await db.insert('settings', {'key': 'seeded', 'value': 'true'},
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    // Incremental seeding for devices that already installed earlier Quiz Lab.
    final reference = await db.query('settings',
        where: 'key=?', whereArgs: ['seeded_user_vocab_v1']);
    if (reference.isEmpty) {
      final data = await rootBundle.loadString('assets/data/user_language_reference.json');
      await importJson(data);
      await db.insert('settings', {'key': 'seeded_user_vocab_v1', 'value': 'true'},
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    // Incremental original 100-topic set. Keep a stable pack id so reviews
    // stay intact across app upgrades and reimports. Never delete user data.
    final original100 = await db.query('settings',
        where: 'key=?', whereArgs: ['seeded_original_100_topics_v1']);
    if (original100.isEmpty) {
      final data = await rootBundle.loadString('assets/data/quizlab_original_100_topics.json');
      await importJson(data);
      await db.insert('settings',
          {'key': 'seeded_original_100_topics_v1', 'value': 'true'},
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// Supports {type:'quiz', questions:[...]} and {type:'language',terms:[...]}.
  /// Imported question IDs are scoped to pack IDs. Existing progress survives
  /// re-imports because the stable per-item keys are upserted, not cleared.
  Future<int> importJson(String source) async {
    final root = jsonDecode(source);
    if (root is! Map) throw const FormatException('JSON root must be an object.');
    final data = Map<String, dynamic>.from(root);
    // User vocabulary schema: {version:1, languages:[...], entries:[
    //   {id, category, subtopic, tags, words:{EN,IT,ES,FR,...}}
    // ]}. Convert on import without mutating the user's source JSON.
    if (data['version'] == 1 && data['entries'] is List && data['languages'] is List) {
      final entries = data['entries'] as List;
      final terms = <Map<String, dynamic>>[];
      for (final raw in entries) {
        if (raw is! Map) throw const FormatException('Vocabulary entry must be an object.');
        final entry = Map<String, dynamic>.from(raw);
        final words = entry['words'];
        if (words is! Map) throw FormatException('Missing words in vocabulary entry: ${entry['id']}');
        final normalized = <String, String>{};
        for (final item in words.entries) {
          final code = item.key.toString().toLowerCase().trim();
          final value = item.value?.toString().trim() ?? '';
          if (code.isNotEmpty && value.isNotEmpty) normalized[code] = value;
        }
        final category = entry['category']?.toString().trim() ?? 'general';
        final subtopic = entry['subtopic']?.toString().trim() ?? 'general';
        terms.add({
          'id': entry['id'],
          'topic': '$category / $subtopic',
          'category': category,
          'subtopic': subtopic,
          'translations': normalized,
        });
      }
      return importJson(jsonEncode({
        'type': 'language',
        'id': data['id'] ?? 'vocabulary-schema-v1',
        'title': data['title'] ?? 'Multilingual vocabulary',
        'terms': terms,
      }));
    }
    final type = data['type'];
    final packId = data['id']?.toString().trim() ?? '';
    final title = data['title']?.toString().trim() ?? '';
    if (packId.isEmpty || title.isEmpty) {
      throw const FormatException('Provide an id and title for the pack.');
    }
    final db = await database;
    if (type == 'quiz') {
      final questions = data['questions'];
      if (questions is! List || questions.isEmpty) {
        throw const FormatException('Quiz pack requires nonempty questions array.');
      }
      final items = <QuizQuestion>[];
      final seen = <String>{};
      for (final raw in questions) {
        if (raw is! Map) throw const FormatException('Question must be an object.');
        final row = Map<String, dynamic>.from(raw);
        final id = row['id']?.toString().trim() ?? '';
        final prompt = row['prompt']?.toString().trim() ?? '';
        final topic = row['topic']?.toString().trim() ?? title;
        final opts = row['options'];
        final answerIndex = row['answerIndex'];
        if (id.isEmpty || !seen.add(id) || prompt.isEmpty ||
            opts is! List || opts.length < 2 ||
            opts.any((e) => e is! String || e.trim().isEmpty) ||
            opts.map((e) => e.toString().toLowerCase().trim()).toSet().length != opts.length ||
            answerIndex is! int || answerIndex < 0 || answerIndex >= opts.length) {
          throw FormatException('Invalid or duplicate question id: $id');
        }
        items.add(QuizQuestion(
          id: id, packId: packId, topic: topic, prompt: prompt,
          options: opts.cast<String>(), answerIndex: answerIndex,
          explanation: row['explanation']?.toString() ?? '',
        ));
      }
      await db.transaction((tx) async {
        for (final question in items) {
          await tx.insert('questions', question.toDatabase(),
              conflictAlgorithm: ConflictAlgorithm.replace);
        }
      });
      return items.length;
    }
    if (type == 'language') {
      final terms = data['terms'];
      if (terms is! List || terms.isEmpty) {
        throw const FormatException('Language pack requires nonempty terms array.');
      }
      final entries = <Map<String, Object?>>[];
      final seen = <String>{};
      for (final raw in terms) {
        if (raw is! Map) throw const FormatException('Term must be an object.');
        final row = Map<String, dynamic>.from(raw);
        final id = row['id']?.toString().trim() ?? '';
        final category = row['category']?.toString().trim() ?? '';
        final subtopic = row['subtopic']?.toString().trim() ?? '';
        final explicitTopic = row['topic']?.toString().trim() ?? '';
        final topic = category.isNotEmpty && subtopic.isNotEmpty
            ? '$category / $subtopic'
            : explicitTopic.isNotEmpty ? explicitTopic : title;
        final translations = row['translations'];
        if (id.isEmpty || !seen.add(id) || translations is! Map || translations.length < 2 ||
            translations.values.any((v) => v is! String || v.trim().isEmpty)) {
          throw FormatException('Invalid or duplicate language term: $id');
        }
        entries.add({
          'id': '$packId:$id', 'raw_id': id, 'pack_id': packId,
          'topic': topic,
          'translations_json': jsonEncode(translations),
        });
      }
      await db.transaction((tx) async {
        for (final row in entries) {
          await tx.insert('language_terms', row,
              conflictAlgorithm: ConflictAlgorithm.replace);
        }
      });
      return entries.length;
    }
    throw const FormatException('type must be "quiz" or "language".');
  }

  Future<List<QuizQuestion>> questions() async {
    final db = await database;
    final rows = await db.query('questions', orderBy: 'topic ASC, id ASC');
    return rows.map(QuizQuestion.fromDatabase).toList();
  }

  Future<List<LanguageTerm>> languageTerms() async {
    final db = await database;
    final rows = await db.query('language_terms', orderBy: 'topic ASC, id ASC');
    return rows.map((row) => LanguageTerm(
      id: row['raw_id'] as String,
      packId: row['pack_id'] as String,
      topic: row['topic'] as String,
      translations: (jsonDecode(row['translations_json'] as String) as Map)
          .map((key, value) => MapEntry(key.toString(), value.toString())),
    )).toList();
  }

  Future<Map<String, ReviewProgress>> allProgress() async {
    final db = await database;
    final rows = await db.query('progress');
    return {for (final row in rows) row['item_id'] as String: ReviewProgress.fromDatabase(row)};
  }

  Future<ReviewProgress> logAnswer(QuizQuestion question, {
    required bool correct,
    required ReviewRating rating,
    required DateTime timestamp,
    required int elapsedMs,
  }) async {
    final db = await database;
    return db.transaction((tx) async {
      final oldRows = await tx.query('progress',
          where: 'item_id=?', whereArgs: [question.itemKey]);
      final old = oldRows.isEmpty
          ? ReviewProgress.fresh(question.itemKey)
          : ReviewProgress.fromDatabase(oldRows.first);
      final updated = ReviewEngine.record(
          previous: old, now: timestamp, correct: correct, rating: rating);
      await tx.insert('progress', updated.toDatabase(),
          conflictAlgorithm: ConflictAlgorithm.replace);
      await tx.insert('attempts', AttemptRecord(
        itemId: question.itemKey,
        topic: question.topic,
        category: question.category,
        sourceLanguage: question.sourceLanguage,
        targetLanguage: question.targetLanguage,
        correct: correct,
        rating: rating.name,
        timestamp: timestamp,
        elapsedMs: elapsedMs,
      ).toDatabase());
      return updated;
    });
  }

  Future<List<Map<String, Object?>>> dailyStats() async {
    final db = await database;
    return db.rawQuery('''SELECT substr(answered_at,1,10) AS day,
        COUNT(*) AS attempts, SUM(correct) AS correct,
        SUM(elapsed_ms) AS elapsed_ms FROM attempts
        GROUP BY substr(answered_at,1,10) ORDER BY day DESC''');
  }

  Future<List<Map<String, Object?>>> topicStats() async {
    final db = await database;
    return db.rawQuery('''SELECT topic, COUNT(*) AS attempts,
        SUM(correct) AS correct, COUNT(DISTINCT item_id) AS reviewed_items,
        SUM(elapsed_ms) AS elapsed_ms FROM attempts
        GROUP BY topic ORDER BY (1.0 * SUM(correct)/COUNT(*)) ASC, attempts DESC''');
  }

  Future<List<Map<String, Object?>>> languageDirectionStats() async {
    final db = await database;
    return db.rawQuery('''SELECT source_lang, target_lang,
        COUNT(*) AS attempts, SUM(correct) AS correct,
        COUNT(DISTINCT item_id) AS reviewed_items FROM attempts
        WHERE category='language' GROUP BY source_lang, target_lang
        ORDER BY attempts DESC''');
  }

  Future<List<Map<String, Object?>>> questionStats() async {
    final db = await database;
    return db.rawQuery('''SELECT item_id, topic, COUNT(*) AS attempts,
        SUM(correct) AS correct, SUM(CASE WHEN correct=0 THEN 1 ELSE 0 END) AS wrong
        FROM attempts GROUP BY item_id, topic ORDER BY wrong DESC, attempts DESC''');
  }

  Future<String?> setting(String key) async {
    final db = await database;
    final rows = await db.query('settings', where: 'key=?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }

  Future<void> saveSetting(String key, String value) async {
    final db = await database;
    await db.insert('settings', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
