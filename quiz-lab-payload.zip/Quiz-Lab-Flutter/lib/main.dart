import 'package:flutter/material.dart';
import 'cloud/supabase_quiz_service.dart';
import 'data/study_database.dart';
import 'state/study_state.dart';
import 'ui/home_screen.dart';
import 'ui/shared.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupabaseQuizService.instance.initialize();
  runApp(StudyApp(state: StudyState(StudyDatabase.instance)));
}

class StudyScope extends InheritedNotifier<StudyState> {
  const StudyScope({super.key, required StudyState state, required super.child})
      : super(notifier: state);

  static StudyState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<StudyScope>()!.notifier!;
}

class StudyApp extends StatefulWidget {
  const StudyApp({super.key, required this.state});
  final StudyState state;
  @override
  State<StudyApp> createState() => _StudyAppState();
}

class _StudyAppState extends State<StudyApp> {
  @override
  void initState() {
    super.initState();
    widget.state.initialize();
  }

  @override
  Widget build(BuildContext context) => StudyScope(
    state: widget.state,
    child: MaterialApp(
      title: 'Quiz Lab',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: const ColorScheme.dark(primary: cyan, secondary: cyan,
          surface: deepBlue, onPrimary: ink),
        appBarTheme: const AppBarTheme(backgroundColor: ink, elevation: 0),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: deepBlue,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
          backgroundColor: cyan, foregroundColor: ink,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        )),
      ),
      home: AnimatedBuilder(
        animation: widget.state,
        builder: (context, child) {
          if (widget.state.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
          if (widget.state.loadError != null) {
            return Scaffold(body: Center(child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text('Database initialization failed:\n${widget.state.loadError}'),
            )));
          }
          return const HomeScreen();
        },
      ),
    ),
  );
}
