import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/domain/review_engine.dart';
import 'package:quiz_app/models/quiz_models.dart';

void main() {
  final start = DateTime(2026, 10, 5, 12);
  ReviewProgress give(ReviewProgress p, int day, bool correct) => ReviewEngine.record(
    previous: p,
    now: start.add(Duration(days: day)),
    correct: correct,
    rating: correct ? ReviewRating.good : ReviewRating.again,
  );

  test('3 + 2 + 1 on separate consecutive weeks yields mastery', () {
    var p = ReviewProgress.fresh('a');
    p = give(p, 0, true);
    p = give(p, 1, true);
    p = give(p, 2, true);
    expect(p.mastered, false);
    expect(p.week1, 3);
    p = give(p, 7, true);
    p = give(p, 8, true);
    expect(p.week2, 2);
    expect(p.mastered, false);
    p = give(p, 14, true);
    expect(p.mastered, true);
    expect(p.nextDue, null);
    expect(ReviewEngine.traffic(p), TrafficLight.green);
  });

  test('missing week 1 or week 2 quota resets the cycle', () {
    var p = ReviewProgress.fresh('b');
    p = give(p, 0, true);
    p = give(p, 7, true);
    expect(p.week1, 1);
    expect(p.week2, 0);
    expect(ReviewEngine.weekIndex(p, start.add(const Duration(days: 7))), 0);
    expect(p.mastered, false);

    p = give(p, 8, true);
    p = give(p, 9, true);
    p = give(p, 14, true); // Week 2 of restarted cycle, only 1 correct.
    p = give(p, 21, true); // Week 3 would be invalid; restart.
    expect(p.week1, 1);
    expect(p.week2, 0);
    expect(p.mastered, false);
  });

  test('an incorrect answer after mastery revokes mastery', () {
    var p = ReviewProgress.fresh('c');
    for (final d in [0, 1, 2, 7, 8, 14]) {
      p = give(p, d, true);
    }
    expect(p.mastered, true);
    p = give(p, 22, false);
    expect(p.mastered, false);
    expect(p.week1, 0);
    expect(p.wrongTotal, 1);
    expect(ReviewEngine.traffic(p), TrafficLight.red);
  });

  test('wrong answers always rank above fewer wrong answers', () {
    var a = ReviewProgress.fresh('a');
    var b = ReviewProgress.fresh('b');
    a = give(a, 0, false);
    a = give(a, 0, false);
    b = give(b, 0, false);
    expect(ReviewEngine.comparePriority(a, b, start), lessThan(0));
  });

  test('weekly quotas never count wrong answers as correct', () {
    var p = ReviewProgress.fresh('d');
    p = give(p, 0, true);
    p = give(p, 1, false);
    p = give(p, 2, true);
    expect(p.week1, 2);
    expect(p.wrongTotal, 1);
  });
}
