import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/data/study_database.dart';
import 'package:quiz_app/models/quiz_models.dart';
import 'package:quiz_app/state/study_state.dart';

void main() {
  LanguageTerm term(String id, String topic, String es, String pt) => LanguageTerm(
    id: id, packId: 'dict', topic: topic,
    translations: {'es': es, 'pt': pt, 'en': id},
  );

  test('category/subcategory checkboxes use tri-state selection', () {
    final state = StudyState(StudyDatabase.instance);
    final a = term('hand', 'people / hand', 'mano', 'mão');
    final b = term('foot', 'people / foot', 'pie', 'pé');
    expect(state.vocabularyGroupSelection([a, b]), true);
    state.excludedVocabularyIds.add(state.vocabularyId(a));
    expect(state.vocabularyGroupSelection([a, b]), null);
    expect(state.vocabularyGroupSelection([a]), false);
    state.excludedVocabularyIds.add(state.vocabularyId(b));
    expect(state.vocabularyGroupSelection([a, b]), false);
  });

  test('selected two-word group still uses global distractor pool', () {
    final state = StudyState(StudyDatabase.instance);
    state.terms = [
      term('hand', 'people / hand', 'mano', 'mão'),
      term('foot', 'people / foot', 'pie', 'pé'),
      term('head', 'people / body', 'cabeza', 'cabeça'),
      term('back', 'people / body', 'espalda', 'costas'),
    ];
    state.excludedVocabularyIds.add(state.vocabularyId(state.terms[2]));
    state.excludedVocabularyIds.add(state.vocabularyId(state.terms[3]));
    final questions = state.languageQuestions();
    expect(questions.length, 2);
    expect(questions.every((q) => q.options.length == 4), true);
  });

  test('counts each word once and respects selection in stats', () {
    final state = StudyState(StudyDatabase.instance);
    final a = term('hand', 'people / hand', 'mano', 'mão');
    final b = term('foot', 'people / foot', 'pie', 'pé');
    state.excludedVocabularyIds.add(state.vocabularyId(b));
    state.terms = [a, b];
    final questions = state.allLanguageQuestions(); // 2 terms cannot yield 4 choices.
    expect(questions, isEmpty);
    final totals = state.vocabularyStats(state.terms, {});
    expect(totals.total, 2);
    expect(totals.selected, 1);
    expect(totals.available, 0);
    expect(totals.attempts, 0);
    expect(totals.accuracy, '—');
  });
}
