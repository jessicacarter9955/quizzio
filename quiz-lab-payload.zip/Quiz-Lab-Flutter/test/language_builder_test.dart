import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/domain/language_builder.dart';
import 'package:quiz_app/models/quiz_models.dart';

void main() {
  test('Spanish to Portuguese with English prompt and Portuguese answers', () {
    final terms = [
      const LanguageTerm(id: 'arm', packId: 'body', topic: 'Body parts',
        translations: {'es': 'brazo', 'pt': 'braço'}),
      const LanguageTerm(id: 'foot', packId: 'body', topic: 'Body parts',
        translations: {'es': 'pie', 'pt': 'pé'}),
      const LanguageTerm(id: 'head', packId: 'body', topic: 'Body parts',
        translations: {'es': 'cabeza', 'pt': 'cabeça'}),
      const LanguageTerm(id: 'eye', packId: 'body', topic: 'Body parts',
        translations: {'es': 'ojo', 'pt': 'olho'}),
    ];
    final quiz = LanguageBuilder.build(terms,
      source: 'es', target: 'pt', uiLanguage: 'en');
    expect(quiz.length, 4);
    expect(quiz.first.prompt, 'How do you say "brazo" in Portuguese?');
    expect(quiz.first.options, containsAll(['braço', 'pé', 'cabeça', 'olho']));
    expect(quiz.first.options[quiz.first.answerIndex], 'braço');
    expect(quiz.first.itemKey, 'language:body:arm:es>pt');
  });
}
