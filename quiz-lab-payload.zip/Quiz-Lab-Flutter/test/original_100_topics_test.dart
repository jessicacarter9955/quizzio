import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/models/quiz_models.dart';
import 'package:quiz_app/domain/language_builder.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('The bundled original curriculum has 100 topics and 800 complete entries', () async {
    final raw = await rootBundle.loadString('assets/data/quizlab_original_100_topics.json');
    final data = jsonDecode(raw) as Map<String,dynamic>;
    expect(data['type'], 'language');
    final rows = (data['terms'] as List).cast<Map<String,dynamic>>();
    expect(rows.length,800);
    final topics = rows.map((r) => r['topic']).toSet();
    expect(topics.length,100);
    expect(rows.map((r) => r['category']).toSet().length,15);
    for (final item in rows) {
      expect((item['translations'] as Map).keys.toSet(),{'en','fr','de','es','it'});
      expect((item['translations'] as Map).values.every((v)=>v.toString().isNotEmpty),true);
    }
  });

  test('Ambiguous source words show the subtopic context rather than being omitted', () {
    const terms=<LanguageTerm>[
      LanguageTerm(id:'food',packId:'x',topic:'Food / Fruit',translations:{'fr':'pêche','en':'peach'}),
      LanguageTerm(id:'hobby',packId:'x',topic:'Leisure / Outdoor',translations:{'fr':'pêche','en':'fishing'}),
      LanguageTerm(id:'a',packId:'x',topic:'Food / Fruit',translations:{'fr':'pomme','en':'apple'}),
      LanguageTerm(id:'b',packId:'x',topic:'Food / Fruit',translations:{'fr':'poire','en':'pear'}),
      LanguageTerm(id:'c',packId:'x',topic:'Food / Fruit',translations:{'fr':'fraise','en':'strawberry'}),
    ];
    final questions=LanguageBuilder.build(terms,source:'fr',target:'en');
    expect(questions.length,5);
    expect(questions.first.prompt,contains('Food / Fruit'));
    expect(questions[1].prompt,contains('Leisure / Outdoor'));
    expect(questions.first.options[questions.first.answerIndex],'peach');
    expect(questions[1].options[questions[1].answerIndex],'fishing');
  });
}
