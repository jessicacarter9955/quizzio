import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/data/study_database.dart';
import 'package:quiz_app/state/study_state.dart';
import 'package:quiz_app/models/quiz_models.dart';

void main() {
  final word = LanguageTerm(id:'apple',packId:'test',topic:'Food / Fruit',
    translations:{'en':'apple','es':'manzana','fr':'pomme'});
  final phrase = LanguageTerm(id:'hello',packId:'test',topic:'Reference / Greetings',
    kind:'phrase',translations:{'en':'Good morning','es':'Buenos días','fr':'Bonjour'});
  test('Vocabulary and phrasebook are two exclusive tracks', () {
    final state=StudyState(StudyDatabase.instance);
    state.terms=[word,phrase];
    state.sourceLanguage='en';state.targetLanguage='es';
    expect(state.filteredLanguageTerms.length,1);
    expect(state.filteredLanguageTerms.first.id,'apple');
    state.languageContentFilter='phrases';
    expect(state.filteredLanguageTerms.length,1);
    expect(state.filteredLanguageTerms.first.id,'hello');
  });
  test('Directions require distinct languages and available content', () {
    final state=StudyState(StudyDatabase.instance);
    state.terms=[word,phrase];
    state.sourceLanguage='es';state.targetLanguage='es';
    state.normalizeLanguagePair();
    expect(state.sourceLanguage,isNot(state.targetLanguage));
    expect(state.hasLanguagePair(state.sourceLanguage,state.targetLanguage),isTrue);
  });
  test('Similarity labels are reverse-direction symmetric and not mastery scores', () {
    final state=StudyState(StudyDatabase.instance);
    state.sourceLanguage='es';state.targetLanguage='en';
    final key1=state.similarityKey(word);
    state.sourceLanguage='en';state.targetLanguage='es';
    expect(state.similarityKey(word),key1);
    expect(state.manualColor(word),'neutral');
  });
  test('Writing attempts filter by current track independently', () {
    final state=StudyState(StudyDatabase.instance);
    state.sourceLanguage='en';state.targetLanguage='es';
    state.writingAttempts.addAll([
      {'kind':'words','source':'en','target':'es','outcome':'revealed'},
      {'kind':'phrases','source':'en','target':'es','outcome':'correct'},
      {'kind':'words','source':'es','target':'en','outcome':'wrong'},
    ]);
    expect(state.currentWritingAttempts.length,1);
    expect(state.currentWritingAttempts.first['outcome'],'revealed');
    state.languageContentFilter='phrases';
    expect(state.currentWritingAttempts.length,1);
    expect(state.currentWritingAttempts.first['outcome'],'correct');
  });
}
