import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/models/quiz_models.dart';
import 'package:quiz_app/domain/language_builder.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('400-page continuation contains 808 vocabulary entries and 196 phrases', () async {
    final content = await rootBundle.loadString('assets/data/quizlab_400_continuation.json');
    final root = jsonDecode(content) as Map<String,dynamic>;
    final terms=(root['terms'] as List).cast<Map<String,dynamic>>();
    expect(terms.length,1004);
    expect(terms.where((t)=>t['kind']=='word').length,808);
    expect(terms.where((t)=>t['kind']=='phrase').length,196);
    expect(terms.map((t)=>t['id']).toSet().length,terms.length);
    for (final t in terms) {
      expect((t['translations'] as Map).keys.toSet(),{'en','fr','de','es','it'});
      expect((t['translations'] as Map).values.every((v)=>v.toString().trim().isNotEmpty),true);
    }
  });
  test('phrase prompts and tracked topics do not merge with word prompts', () {
    final terms = <LanguageTerm>[
      for (var i=0; i<5; i++) LanguageTerm(id:'phrase-$i', packId:'phr', topic:'Services / Directions', kind:'phrase', translations:{
        'en':'Where is place $i?', 'fr':'Où est le lieu $i ?'}),
      for (var i=0; i<5; i++) LanguageTerm(id:'word-$i', packId:'phr', topic:'Services / Signs', kind:'word', translations:{
        'en':'sign $i', 'fr':'panneau $i'}),
    ];
    final q = LanguageBuilder.build(terms,source:'en',target:'fr');
    expect(q.where((x)=>x.topic.startsWith('Languages / Phrasebook /')).length,5);
    expect(q.where((x)=>!x.topic.startsWith('Languages / Phrasebook /')).length,5);
  });
}
