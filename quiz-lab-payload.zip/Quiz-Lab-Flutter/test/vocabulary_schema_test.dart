import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:quiz_app/domain/language_builder.dart';
import 'package:quiz_app/models/quiz_models.dart';

void main() {
  test('Dictionary category and subcategory are represented in topic', () {
    final terms = <LanguageTerm>[
      const LanguageTerm(id:'apple',packId:'visual',topic:'food / fruit',
          translations:{'en':'apple','fr':'pomme','de':'Apfel','es':'manzana','it':'mela'}),
      const LanguageTerm(id:'pear',packId:'visual',topic:'food / fruit',
          translations:{'en':'pear','fr':'poire','de':'Birne','es':'pera','it':'pera'}),
      const LanguageTerm(id:'peach',packId:'visual',topic:'food / fruit',
          translations:{'en':'peach','fr':'pêche','de':'Pfirsich','es':'melocotón','it':'pesca'}),
      const LanguageTerm(id:'plum',packId:'visual',topic:'food / fruit',
          translations:{'en':'plum','fr':'prune','de':'Pflaume','es':'ciruela','it':'prugna'}),
    ];
    final questions = LanguageBuilder.build(terms,source:'es',target:'it');
    expect(questions,hasLength(4));
    expect(questions.first.topic,'Languages / food / fruit');
    expect(questions.first.prompt,contains('Italian'));
    for(final q in questions) {
      expect(q.options,hasLength(4));
      expect(q.options.toSet().length,4);
    }
  });
}
