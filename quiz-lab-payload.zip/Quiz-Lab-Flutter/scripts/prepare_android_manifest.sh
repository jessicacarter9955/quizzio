#!/usr/bin/env bash
# Enable HTTPS access for Supabase in Android main/release manifests.
set -euo pipefail
MANIFEST="$1/android/app/src/main/AndroidManifest.xml"
if [[ ! -f "$MANIFEST" ]]; then
  echo "Missing generated AndroidManifest: $MANIFEST" >&2
  exit 1
fi
if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
  sed -i '/<application/i\    <uses-permission android:name="android.permission.INTERNET" />' "$MANIFEST"
fi
