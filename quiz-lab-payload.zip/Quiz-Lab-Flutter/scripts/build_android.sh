#!/usr/bin/env bash
# Run from anywhere with Flutter stable + Android SDK installed.
# Recreates modern Flutter Android/iOS platform files rather than relying
# on the source repository's obsolete 2021 Android Gradle setup.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="${1:-$SOURCE_DIR/../quiz_lab_build}"

if ! command -v flutter >/dev/null; then
  echo 'Flutter not found: install Flutter stable first.' >&2
  exit 1
fi
if [[ -e "$OUTPUT_DIR" ]]; then
  echo "Output folder exists: $OUTPUT_DIR (choose a fresh destination)." >&2
  exit 1
fi
flutter create --org dev.quizlab --project-name quiz_app --platforms=android,ios "$OUTPUT_DIR"
rm -rf "$OUTPUT_DIR/lib" "$OUTPUT_DIR/test"
cp -R "$SOURCE_DIR/lib" "$OUTPUT_DIR/lib"
cp -R "$SOURCE_DIR/test" "$OUTPUT_DIR/test"
cp -R "$SOURCE_DIR/assets" "$OUTPUT_DIR/assets"
cp "$SOURCE_DIR/pubspec.yaml" "$OUTPUT_DIR/pubspec.yaml"
bash "$SOURCE_DIR/scripts/prepare_android_manifest.sh" "$OUTPUT_DIR"
cd "$OUTPUT_DIR"
flutter pub get
flutter test
flutter build apk --debug \
  --dart-define=SUPABASE_URL="${SUPABASE_URL:-}" \
  --dart-define=SUPABASE_PUBLISHABLE_KEY="${SUPABASE_PUBLISHABLE_KEY:-}"
printf '\nBuilt installable debug APK: %s\n' "$OUTPUT_DIR/build/app/outputs/flutter-apk/app-debug.apk"
