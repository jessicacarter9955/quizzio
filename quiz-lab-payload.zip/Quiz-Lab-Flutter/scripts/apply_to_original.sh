#!/usr/bin/env bash
# Apply the replacement Dart learning app to a local checkout of upstream.
# Creates a backup of the old lib/pubspec on the same machine.
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${1:-}"
if [[ -z "$DEST" || ! -f "$DEST/pubspec.yaml" || ! -d "$DEST/lib" ]]; then
  echo "Usage: bash scripts/apply_to_original.sh /path/to/Quiz-App-Flutter" >&2
  exit 1
fi
DEST="$(cd "$DEST" && pwd)"
BACKUP="${DEST}/legacy-source-backup"
if [[ -e "$BACKUP" ]]; then
  echo "Backup directory already exists: $BACKUP. Move it first." >&2
  exit 1
fi
mkdir -p "$BACKUP"
cp -R "$DEST/lib" "$BACKUP/lib"
cp "$DEST/pubspec.yaml" "$BACKUP/pubspec.yaml"
rm -rf "$DEST/lib"
cp -R "$SRC/lib" "$DEST/lib"
rm -rf "$DEST/test"
cp -R "$SRC/test" "$DEST/test"
mkdir -p "$DEST/assets/data" "$DEST/.github/workflows"
cp -R "$SRC/assets/data/." "$DEST/assets/data/"
cp "$SRC/pubspec.yaml" "$DEST/pubspec.yaml"
cp "$SRC/.github/workflows/android-apk.yml" "$DEST/.github/workflows/android-apk.yml"
cp "$SRC/README.md" "$DEST/QUIZ_LAB_README.md"
echo "Applied modern Quiz Lab overlay to $DEST"
echo "Original lib and pubspec backed up in $BACKUP"
echo "For Android builds, use GitHub Actions workflow or generate fresh platform folders."
