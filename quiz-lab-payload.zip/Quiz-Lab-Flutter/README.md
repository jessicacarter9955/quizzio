# Quiz Lab — Quiz-App-Flutter learning-system upgrade

A replacement `lib/` + `pubspec.yaml` overlay built around the visual style and multiple-choice flow of [abuanwar072/Quiz-App-Flutter](https://github.com/abuanwar072/Quiz-App-Flutter). This overlay is **not** a compiled APK. Modern Flutter platform files should be freshly generated because the original Android toolchain is obsolete.

## 5-language illustrated dictionary parser (October 2026)

The 2003/2020 DK *5 Language Visual Dictionary* (English, French, German, Spanish, Italian) is copyrighted. The **complete PDF is not included**: [Open Library's loan/catalog record](https://openlibrary.org/books/OL3701700M/5_language_visual_dictionary.) and the [DK publisher](https://dk.com/products/9780241413036-5-language-visual-dictionary) provide lawful access paths.

New separate Python parser in [`tools/dictionary_parser`](tools/dictionary_parser/README.md):

```sh
pip install -r tools/dictionary_parser/requirements.txt
python tools/dictionary_parser/parser.py /path/to/your-legitimate-dictionary.pdf --out extracted-vocab
```

It traverses the PDF page-by-page and extracts five-way EN/FR/DE/ES/IT candidate word records with **category, subtopic, and source PDF page coordinates**. It emits both the user's original `version:1 / languages / entries / words` format and a Quiz Lab `type: language` pack, plus `entries-review.csv` and `review.csv` for manual audit. Scanned images require a searchable/OCRed PDF. Real DK PDF accuracy **has not been measured** because the complete source PDF was not available lawfully for automated download; compare entries visually before treating them as correct.

The app now imports the user's `language-quiz(1).json` **directly**, including the 13 language/script codes and `category / subtopic` filters, both locally and to Supabase (when configured). The 67 original user-provided terms are bundled as starter vocabulary (`assets/data/user_language_reference.json`) and a standalone importable Quiz Lab pack (`assets/data/user_language_quizlab.json`). A 5-question synthetic PDF fixture in the parser examples demonstrates the pipeline without copying book material.

This Flutter build does not parse PDF files *on-device*: run the Python converter separately, then import its JSON in Quiz Lab's **Library** tab. Progress still follows the existing 3/2/1-week schedule and stays per language direction. The source book illustrations are not redistributed.

## Supabase cloud + local JSON (new)

Quizzes now have **two destinations**:

1. **Local SQLite:** Every JSON import is validated and stored offline; study attempts, mastery state, daily/topic/language stats, and prioritized reviews stay local.
2. **Supabase Postgres:** A signed-in user can upload a quiz or language JSON pack to their own `quiz_packs` row (JSONB), then download their own packs on another device. The same pack ID is safely replaced if uploaded again. Supabase is optional; the app works without cloud configuration. **Progress history does not sync to Supabase in this version**.

### Connect your Supabase project

1. Create a Supabase project at https://supabase.com/dashboard . In **SQL Editor**, run [supabase/schema.sql](supabase/schema.sql). The schema enables Row Level Security; only an authenticated owner can access their own packs.
2. In **Project Settings → API / Connect**, copy the project URL and the client-safe **publishable key** (not a secret or service-role key). Enable Email authentication in Supabase Auth; if confirm-email is enabled, verify your address after sign-up.
3. Build with `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`. For **GitHub Actions**, put these as repository **Actions secrets** named `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`, then run **Build Quiz Lab Android APK**. For **local builds**, run `SUPABASE_URL=https://your-ref.supabase.co SUPABASE_PUBLISHABLE_KEY=sb_publishable_... bash scripts/build_android.sh`.
4. Open the app's **Cloud** tab, create an account or sign in. In the **Library** tab press **Upload JSON → Supabase + local**, choose a `.json` quiz or language pack, then check the confirmation. You can also upload JSON pasted into the text field.
5. On your other device, sign into the **Cloud** tab and press **Download my Supabase quizzes**. Existing local study progress on the device remains intact.

**Privacy/security:** The app sends only JSON packs; it does not send answer history or statistics to the cloud. Each user's uploaded packs are private to their account by RLS. Never embed the Supabase service-role or secret key in any Flutter build. The project URL and publishable key are public client configuration, not credentials granting unrestricted database access.

**Import behavior:** A cloud upload first validates and imports a pack locally. If the cloud request fails, the local import may still have succeeded; a status message makes this clear. Re-uploading the same `id` replaces the stored cloud pack. Downloading uses the same local importer and preserves all progress keys.

**GitHub repo:** This deliverable is a standalone, git-ready application source package based on the original app's idea. The GitHub connection available here can read the original but cannot create new GitHub repositories. See `GITHUB_SETUP.md` for the new-repo steps. No GitHub remote was created automatically.

## What changed

- **Two modes:** Automatic (correct -> Good / incorrect -> Again) and Anki-style (Again, Hard, Good, Easy after selecting an answer). Wrong answers always count as wrong regardless of self-rating.
- **Three-week mastery:** Week 1: 3 correct answers; Week 2: 2; Week 3: 1. Seven-day intervals begin at midnight on the local date of the first recorded attempt. The weeks must be consecutive. A missed weekly quota restarts the three-week cycle on the next attempt. Mastered items are excluded from the priority queue and colored green; a later wrong answer revokes mastery.
- **Priority:** Total wrong attempts descending, then current wrong streak, then due status. Green mastered items sink to the bottom and are hidden by default.
- **Traffic lights:** Red = recent wrong streak or wrong attempts >= correct attempts; Yellow = unmastered/learning; Green = completed 3+2+1 milestone. A fresh item is yellow.
- **Spaced due dates:** Due-only is the default in both quiz and language sessions; turn it off in filters to practice early.  Incorrect/Again: 5 minutes; Hard: 6 hours; Good: 1 day; Easy: 3 days. Completing the week's quota defers the next due date until the next week's start. These rules are **custom scheduling, not a verified FSRS algorithm**.
- **Stats:** All attempts persist locally in SQLite: daily answers and accuracy, day streak, topic accuracy rankings, most missed question leaderboard, study time, and mastered total.
- **Languages:** Separate source, target, and UI-question languages. Defaults are Spanish -> Portuguese, **English instructions**. Options are all in Portuguese for this direction (e.g. `How do you say "brazo" in Portuguese?`). Mastery and error histories are separate for each direction (`es>pt` differs from `pt>es`).
- **JSON imports:** Import quiz and parallel language term packs by file picker or paste. Stable pack/item IDs allow reimporting without losing history.
- **Offline-first:** No account or internet needed for local study. Optional cloud quiz-pack sync requires Supabase and login.

## Build locally

Requires recent Flutter stable and Android SDK. In this folder:

```bash
bash scripts/build_android.sh
```

The script creates `../quiz_lab_build/`, generates modern platform folders, runs tests, then builds `../quiz_lab_build/build/app/outputs/flutter-apk/app-debug.apk`. You may also specify a fresh output folder as the first argument.

**GitHub Actions:** Upload these files to your own (writable) repository, enable Actions and run `Build Quiz Lab Android APK` (`workflow_dispatch`). Download the debug APK from the workflow's Artifacts section after the build succeeds. The original upstream repo is read-only to this tool connection, so no changes have been committed there.

If Android says “App not installed” due to a mismatched debug signing key when replacing an old `com.example.quiz_app`, uninstall the old debug installation first (its local data will be deleted). To retain existing installs, configure a consistent signing key and a migration plan.

## Quiz JSON schema

```json
{
  "type": "quiz", "id": "my-quiz", "title": "Knowledge",
  "questions": [{
    "id": "q1", "topic": "Science", "prompt": "What is H2O?",
    "options": ["Water", "Oxygen", "Salt", "Air"],
    "answerIndex": 0, "explanation": "H2O is water."
  }]
}
```

`answerIndex` is **zero-based**. Each question requires >=2 nonempty distinct choices. Questions are identified by stable `pack id + question id`.

## Language JSON schema

```json
{
  "type": "language", "id": "vocabulary-body", "title": "Body parts",
  "terms": [
    {"id":"arm", "topic":"Body parts", "translations": {
      "en":"arm", "es":"brazo", "pt":"braço", "it":"braccio"
    }},
    {"id":"head", "topic":"Body parts", "translations": {
      "en":"head", "es":"cabeza", "pt":"cabeça", "it":"testa"
    }}
  ]
}
```

A pair needs at least **four terms with distinct target translations** before multiple-choice can be generated. Add any language code to translations (supported selection UI includes `en,es,pt,it,fr,de,ru,ja,zh,ko`). Language question IDs are based on `pack + term + direction` so progress does not mix directions. Add multiple language packs with stable IDs; terms are stored and indexed locally.

**Important:** The import schema here is provisional. When you provide your JSON later, we'll add a compatible adapter instead of requiring you to rewrite the dataset.

## Source layout

- `lib/domain/review_engine.dart`: deterministic weekly mastery/scheduling/priority logic
- `lib/domain/language_builder.dart`: source/target/UI-language question generation
- `lib/data/study_database.dart`: SQLite schema, transactions, persisted attempts, JSON import
- `lib/state/study_state.dart`: app state and filters
- `lib/ui/`: quiz, languages, statistics, library, and study queue screens
- `assets/data/`: starter quiz pack and multilingual vocabulary
- `test/`: mastery and language-direction unit tests

## Limitations and next steps

- The custom scheduling is not official FSRS, deliberately prioritizing the user's explicit three-week 3/2/1 requirements.
- Multilingual **instruction translations** are initial templates. English is the default and supported precisely. Source word and target answer translations come from JSON.
- Currently multiple-choice only. No audio pronunciation, synonyms, or typed answers. Quiz-pack cloud upload/download and email sign-in are available, but review history stays local.
- No signed release APK is included; the workflow builds a debug installable APK.
- Local persistence is per Android installation. Clearing app data/uninstalling removes it; implement export/backups before real use if data preservation is essential.

## Multilingual vocabulary hierarchy (October 2026)

The Languages tab now contains an expandable, tri-state checkbox tree:
**Category → Subcategory → Individual words**. Ticking a category includes
all of its subcategories and words; partial selection is shown as a dash.
Selection is retained across app launches in `excludedVocabularyIds` in the
SQLite settings table. All newly imported words are selected by default.

Each node reports `selected / total` distinct words, `quiz-ready` items for
the selected language pair, due and mastered counts, red/yellow/green counts,
answer attempts, and accuracy. The selected source→target pair is the unit of
progress, while the words are kept only once per imported vocabulary record.
A quiz with just one or two selected words can still use valid distractors
from the rest of the imported data, rather than reporting too few choices.

The supplied `assets/data/dk_dictionary_taxonomy.json` lists the 15 thematic
sections verified in the DK contents page. Only the People's five subdivisions
have been verified from the browsable pages. This is organizational metadata,
not a claim that the entire publisher PDF was acquired or its contents parsed.
The complete copyrighted PDF is **not bundled**. The existing Python PDF parser
processes user-supplied accessible copies, outputs tentative five-language
translations, and requires review/approval before import.
