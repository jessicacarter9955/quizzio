# Publish Quiz Lab as its own GitHub repository

The original is https://github.com/abuanwar072/Quiz-App-Flutter (third-party, read-only). This package is a new app source with the quiz learning system, not a direct commit to that upstream repository. The attached `.bundle` is a real local Git repository snapshot with a first commit.

## Option A — publish from a local checkout

1. On GitHub, open https://github.com/new and create **Quiz-Lab-Flutter** under your account (private or public). Do not check "Initialize with README" since this ZIP already contains one.
2. Extract this ZIP to a folder and open a terminal there.
3. If `.git` is not included in the extracted folder, run:

```bash
git init -b main
git add .
git commit -m "Implement Quiz Lab offline learning and Supabase JSON upload"
```

4. Add your new remote and push (replace YOUR_USERNAME):

```bash
git remote add origin https://github.com/YOUR_USERNAME/Quiz-Lab-Flutter.git
git push -u origin main
```

5. In your repository's Settings → Secrets and variables → Actions, set `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`. Run `Actions → Build Quiz Lab Android APK → Run workflow`.

## Option B — clone the provided Git bundle

A `.bundle` is a complete Git commit snapshot; use `git clone Quiz-Lab-Flutter.bundle Quiz-Lab-Flutter` on your computer, then add the remote as above. It does not automatically create the repository on github.com.

Build a modern platform scaffold using `scripts/build_android.sh` or the GitHub Actions workflow, since the original repository's 2021 Android project is obsolete.
