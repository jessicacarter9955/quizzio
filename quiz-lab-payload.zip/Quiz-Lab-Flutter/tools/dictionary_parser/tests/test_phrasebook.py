from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from parser import classify_content, to_pack

def test_lexical_items_vs_phrases():
    assert classify_content('traffic light','transport','road signs')=='word'
    assert classify_content('How much does this cost?','shopping','prices')=='phrase'
    assert classify_content('Thank you','reference','courtesy')=='phrase'
    assert classify_content('breakfast room','services','hotel')=='word'
    assert classify_content('please call','reference','useful-phrases')=='phrase'

def test_quizlab_pack_keeps_kind():
    term={'id':'p001','category':'reference','subtopic':'useful-phrases','kind':'phrase',
          'words':{'EN':'Where is the station?','FR':'Où est la gare ?',
                   'DE':'Wo ist der Bahnhof?','ES':'¿Dónde está la estación?',
                   'IT':'Dov’è la stazione?'}}
    pack=to_pack([term],'pack','Example')
    assert pack['terms'][0]['kind']=='phrase'
