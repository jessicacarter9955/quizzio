import json
import csv
from pathlib import Path
import sys
import fitz
import pytest
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from parser import as_five, parse_pdf, to_pack, write_outputs


def test_five_terms_and_rejections():
    assert as_five('arm • le bras • der Arm • el brazo • il braccio') == [
        'arm', 'le bras', 'der Arm', 'el brazo', 'il braccio']
    assert as_five('arm • le bras • der Arm') is None
    assert as_five('foot\nle pied\nder Fuß\nel pie\nil piede', allow_stacked=True) == [
        'foot','le pied','der Fuß','el pie','il piede']


def make_fixture(p: Path):
    pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    c=canvas.Canvas(str(p),pagesize=(560,700))
    c.setFont('DejaVuSans',9)
    c.drawString(25,675,'BODY • LE CORPS • DER KÖRPER • EL CUERPO • IL CORPO')
    c.setFont('DejaVuSans',13)
    c.drawString(25,620,'head • la tête • der Kopf • la cabeza • la testa')
    c.setFont('DejaVuSans',9)
    c.drawString(25,580,'arm • le bras • der Arm • el brazo • il braccio')
    # multi-line label with five translations in a single text block
    t=c.beginText(25,540)
    for line in ['leg • la jambe','• das Bein • la pierna','• la gamba']:
        t.textLine(line)
    c.drawText(t)
    c.showPage()
    c.setFont('DejaVuSans',9)
    c.drawString(25,675,'FOOD • LA NOURRITURE • DIE NAHRUNGSMITTEL • LOS ALIMENTOS • IL CIBO')
    c.setFont('DejaVuSans',13)
    c.drawString(25,620,'fruit • le fruit • das Obst • la fruta • la frutta')
    c.setFont('DejaVuSans',9)
    c.drawString(25,570,'apple • la pomme • der Apfel • la manzana • la mela')
    c.drawString(25,520,'incomplete • incomplet • unvollständig')
    c.showPage();c.save()


def test_end_to_end(tmp_path):
    p=tmp_path/'owned-fixture.pdf'
    make_fixture(p)
    entries,reviews=parse_pdf(p)
    words={e['words']['EN']:e for e in entries}
    assert {'head','arm','leg','fruit','apple'}.issubset(words.keys()), (words,reviews)
    assert words['arm']['words']['ES']=='el brazo'
    assert words['apple']['category']=='food'
    assert words['arm']['category']=='uncategorized' or words['arm']['category']=='body'
    assert any('incomplete' in r['raw'] for r in reviews)
    pack=to_pack(entries,'test-pack','test data')
    assert pack['type']=='language'
    assert any(t['translations']['de']=='der Apfel' for t in pack['terms'])
    stats=write_outputs(entries,reviews,tmp_path/'export')
    assert stats['entries']>=5
    assert len(json.loads((tmp_path/'export/quizlab-language-pack.json').read_text())['terms'])>=5


def test_no_text_page_produces_review(tmp_path):
    p = tmp_path/'scan.pdf'
    c = canvas.Canvas(str(p), pagesize=(560,700))
    c.rect(10, 10, 100, 100, stroke=1, fill=1)
    c.showPage();c.save()
    entries,reviews = parse_pdf(p)
    assert entries == []
    assert any(r['reason']=='no_extractable_text_maybe_scan' for r in reviews)


def test_approved_only(tmp_path):
    from approve_entries import approve
    p = tmp_path/'fixture.pdf'
    make_fixture(p)
    entries,reviews = parse_pdf(p)
    out = tmp_path/'export'
    write_outputs(entries,reviews,out)
    csv_file=out/'entries-review.csv'
    rows=list(csv.DictReader(csv_file.open(encoding='utf-8-sig')))
    rows[0]['approved']='yes'
    rows[1]['approved']='no'
    with csv_file.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    pack=approve(csv_file,'reviewed','Reviewed')
    assert len(pack['terms'])==1
    assert pack['terms'][0]['translations']['en']==rows[0]['EN']
