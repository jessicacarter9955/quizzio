from pathlib import Path
import json
from convert_reference import convert


def test_converts_user_schema():
    sample={'version':1,'languages':[{'code':'EN','label':'English'},
           {'code':'FR','label':'French'}], 'entries': [
               {'id':'arm','category':'body','subtopic':'limbs','tags':['anatomy'],
                'words':{'EN':'arm','FR':'le bras'}}]}
    actual=convert(sample)
    assert actual['terms'][0]['topic']=='body / limbs'
    assert actual['terms'][0]['translations']=={'en':'arm','fr':'le bras'}
    assert actual['terms'][0]['tags']==['anatomy']
