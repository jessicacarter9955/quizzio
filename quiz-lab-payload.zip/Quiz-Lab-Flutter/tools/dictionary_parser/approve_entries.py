#!/usr/bin/env python3
"""Publish only explicitly approved/corrected 5-language dictionary extraction rows."""
import argparse
import csv
import json
from pathlib import Path
from parser import LANGS, to_pack


def approve(csv_file:Path, pack_id:str, title:str):
    entries=[]
    seen=set()
    with csv_file.open('r',encoding='utf-8-sig',newline='') as f:
        for i,row in enumerate(csv.DictReader(f),2):
            if row.get('approved','').strip().lower() not in ('yes','y','1','true','ok'):
                continue
            id_=row.get('id','').strip()
            if not id_ or id_ in seen:
                raise ValueError(f'Bad/duplicate approved id on CSV line {i}')
            seen.add(id_)
            translations={k: row.get(k,'').strip() for k in LANGS}
            if any(not s for s in translations.values()):
                raise ValueError(f'Approved line {i} is missing one or more translations')
            category=row.get('category','').strip() or 'uncategorized'
            subtopic=row.get('subtopic','').strip() or 'general'
            try:page=int(row.get('page',''))
            except ValueError:page=0
            kind=row.get('kind','word').strip().lower() or 'word'
            if kind not in {'word','phrase','expression'}:
                raise ValueError(f'Invalid content kind on CSV line {i}: {kind}')
            entries.append({'id':id_, 'category':category,'subtopic':subtopic,'kind':kind,
                            'words':translations,'source':{'page':page,'reviewed':True}})
    return to_pack(entries,pack_id,title)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('csv_file',type=Path)
    p.add_argument('--out',type=Path,default=Path('approved-quiz.json'))
    p.add_argument('--id',default='reviewed-five-language')
    p.add_argument('--title',default='Reviewed 5-Language Visual Dictionary')
    a=p.parse_args()
    pack=approve(a.csv_file,a.id,a.title)
    a.out.write_text(json.dumps(pack,ensure_ascii=False,indent=2),encoding='utf8')
    print(f'Exported {len(pack["terms"])} explicitly approved entries')

if __name__=='__main__':main()
