#!/usr/bin/env python3
"""Extract 5-language (EN/FR/DE/ES/IT) picture-dictionary labels from a lawfully held PDF.

This tool does not fetch books. It processes an input PDF supplied by its lawful holder.
Results are *draft*, not editorially verified. Check review.csv before importing.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

import fitz

LANGS = ("EN", "FR", "DE", "ES", "IT")
LANG_LABELS = {"EN":"English", "FR":"French", "DE":"German", "ES":"Spanish", "IT":"Italian"}
SEPARATOR = re.compile(r"\s*[•●·‧∙]\s*")
NUMBER = re.compile(r"^\d{1,4}$")
JUNK = re.compile(r"(?i)^(english|fran[cç]ais|deutsch|espa[nñ]ol|italiano|index|contents|about this book|how to use this book|[.\d\s]+)$")
DEFAULT_CATEGORIES = {
    "people": "people", "body": "body", "appearance": "appearance", "health": "health",
    "home": "home", "services": "services", "shopping": "shopping",
    "food": "food", "eating out": "eating-out", "study": "study",
    "work": "work", "transport": "transport", "transportation": "transport",
    "sports": "sports", "sport": "sports", "leisure": "leisure",
    "environment": "environment", "reference": "reference",
}


def norm(text: str) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", text)).strip(" •· \t\r\n")


def slug(text: str) -> str:
    s = unicodedata.normalize("NFKD", text)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")
    return s[:48] or "uncategorized"


@dataclass
class Line:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float
    size: float
    block: int


def page_lines(page: fitz.Page) -> list[Line]:
    lines = []
    for bno, block in enumerate(page.get_text("dict")["blocks"]):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            if not spans:
                continue
            text = norm("".join(s.get("text", "") for s in spans))
            if text:
                x0, y0, x1, y1 = line["bbox"]
                lines.append(Line(text, x0, y0, x1, y1,
                                  max(s.get("size", 0.0) for s in spans), bno))
    return sorted(lines, key=lambda l: (l.y0, l.x0))


def as_five(text: str, *, allow_stacked: bool = False) -> list[str] | None:
    """Parse five translations. Bullets must be meaningful separators unless explicitly stacked."""
    source = norm(text)
    if allow_stacked and not SEPARATOR.search(source) and text.count("\n") == 4:
        parts = [norm(p) for p in text.split("\n")]
        return parts if len(parts) == 5 and all(parts) else None
    if SEPARATOR.search(source):
        parts = [norm(p) for p in SEPARATOR.split(source)]
        # Some printed annotations begin with a bullet.
        if parts and not parts[0]:
            parts.pop(0)
        if len(parts) == 5 and all(parts):
            return parts
        return None
    if allow_stacked:
        parts = [norm(p) for p in source.split("\n")]
        if len(parts) == 5 and all(parts):
            return parts
    return None


def header_category(lines: list[Line], width: float, height: float) -> tuple[str | None, set[int]]:
    """Detect the thematic running header in the top region of a DK page."""
    header_blocks = set()
    for line in lines:
        if line.y0 > height * 0.135:
            continue
        first = norm(SEPARATOR.split(line.text)[0]).lower()
        first = re.sub(r"[^a-z\s-]", "", first).strip()
        if first in DEFAULT_CATEGORIES and ("•" in line.text or "·" in line.text or line.text.isupper()):
            header_blocks.add(line.block)
            return DEFAULT_CATEGORIES[first], header_blocks
    return None, header_blocks


def classify_content(english: str, category: str = '', subtopic: str = '') -> str:
    """Conservatively tag complete utterances, not ordinary multiword nouns.

    Never assume that a multiword lexical item is a sentence. A proofreader can
    override the suggestion in entries-review.csv before publishing.
    """
    e = norm(english).strip()
    section = (category + ' ' + subtopic).lower().replace('_', '-')
    if any(mark in section for mark in ('useful-phrase', 'phrasebook', 'greeting-phrase')):
        return 'phrase'
    if e.endswith(('.', '!', '?')) or e.startswith(('¿', '¡')):
        return 'phrase'
    if e.lower() in {'hello', 'good morning', 'good evening', 'good night',
                     'thank you', 'excuse me', 'please', 'goodbye', 'welcome'}:
        return 'phrase'
    if re.match(r'(?i)^(where|when|why|who|how|can|could|would|should|please|may|do|does|did)\b',e):
        return 'phrase' if len(e.split()) > 2 else 'expression'
    return 'word'


def likely_label(tokens: list[str]) -> bool:
    if len(tokens) != 5:
        return False
    if any(len(t) > 90 or len(t) < 1 or NUMBER.fullmatch(t) for t in tokens):
        return False
    if JUNK.fullmatch(tokens[0]):
        return False
    if len(tokens[0].split()) > 9:
        return False
    if len(set(t.casefold() for t in tokens)) == 1:
        return False
    return True


def parse_page(page: fitz.Page, page_no: int, inherited_category: str,
               inherited_subtopic: str, ocr=False) -> tuple[list[dict], list[dict], str, str]:
    lines = page_lines(page)
    category, header_blocks = header_category(lines, page.rect.width, page.rect.height)
    category = category or inherited_category
    subtopic = inherited_subtopic if category == inherited_category else "general"
    results = []
    review = []
    blocks = defaultdict(list)
    for line in lines:
        blocks[line.block].append(line)
    # Coordinates allow downstream visual/manual validation.
    for block_index, blines in blocks.items():
        blines.sort(key=lambda x:(x.y0, x.x0))
        if block_index in header_blocks:
            continue
        blines = [l for l in blines if
                  l.y0 > page.rect.height*.08 and l.y1 < page.rect.height*.968]
        if not blines:
            continue
        if len(blines) == 1 and NUMBER.fullmatch(blines[0].text):
            continue
        candidates = []
        # Top headings can contain translations and become subtopic labels.
        for l in blines:
            parts = as_five(l.text)
            if parts:
                candidates.append((parts, l.x0, l.y0, l.x1, l.y1, l.size))
        # Separate spans with the five terms flowing down multiple lines.
        # Do not combine nearby blocks across different illustrated objects.
        if not candidates and 2 <= len(blines) <= 8:
            joined = " ".join(l.text for l in blines)
            parts = as_five(joined)
            if not parts:
                parts = as_five(" • ".join(l.text for l in blines))
            if not parts and len(blines) == 5:
                parts = as_five("\n".join(l.text for l in blines), allow_stacked=True)
            if parts:
                candidates.append((parts, min(l.x0 for l in blines), min(l.y0 for l in blines),
                                   max(l.x1 for l in blines), max(l.y1 for l in blines),
                                   max(l.size for l in blines)))
        # Some two-line headings have 5 terms but are split in two blocks:
        # report these instead of guessing associations with other visual labels.
        for parts, x0, y0, x1, y1, font_size in candidates:
            if not likely_label(parts):
                review.append({"page":page_no, "reason":"invalid_five_term_label", "raw":" | ".join(parts),
                               "category":category,"subtopic":subtopic,"x0":round(x0,1),"y0":round(y0,1)})
                continue
            # Subtopic is a typographically prominent 5-language title near the page top.
            if y0 < page.rect.height*.21 and font_size >= 11.0:
                subtopic = slug(parts[0])
            term_id = slug(parts[0])
            evidence = f"{page_no}:{int(x0)}:{int(y0)}"
            results.append({"id":term_id,"category":category,"subtopic":subtopic,
                            "kind":classify_content(parts[0],category,subtopic),
                            "tags":[],"words":dict(zip(LANGS, parts)),"source":{
                                "page":page_no,"bbox":[round(x0,1),round(y0,1),round(x1,1),round(y1,1)],
                                "extractor":"pdf-text", "confidence":"candidate", "reference":evidence}})
        if not candidates:
            raw = " / ".join(l.text for l in blines)
            if (SEPARATOR.search(raw) or 3 <= len(blines) <= 5) and not JUNK.fullmatch(raw):
                review.append({"page":page_no,"reason":"incomplete_or_ambiguous_group",
                               "raw":raw[:500],"category":category,"subtopic":subtopic,
                               "x0":round(min(l.x0 for l in blines),1),
                               "y0":round(min(l.y0 for l in blines),1)})
    if not lines:
        review.append({"page":page_no,"reason":"no_extractable_text_maybe_scan",
                       "raw":"Use an OCRed PDF; original scan text unavailable.",
                       "category":category,"subtopic":subtopic,"x0":0,"y0":0})
    return results, review, category, subtopic


def parse_pdf(pdf_path: Path, start_page: int = 1, end_page: int | None = None):
    entries, reviews = [], []
    with fitz.open(pdf_path) as doc:
        limit = min(len(doc), end_page or len(doc))
        if start_page < 1 or start_page > limit:
            raise ValueError("Invalid page range")
        category = "uncategorized"
        subtopic = "general"
        for i in range(start_page-1, limit):
            found, problems, category, subtopic = parse_page(doc[i], i + 1, category, subtopic)
            entries.extend(found)
            reviews.extend(problems)
    for entry in entries:
        # Stable even if extracting just a range of pages later.
        src = entry["source"]
        entry["id"] = (
            f"{entry['category']}-{entry['subtopic']}-{entry['id']}-"
            f"p{src['page']:03d}-x{round(src['bbox'][0])}-y{round(src['bbox'][1])}"
        )
    return entries, reviews


def to_pack(entries: list[dict], pack_id: str, title: str) -> dict:
    return {"type":"language","id":pack_id,"title":title,
            "terms":[{"id":e["id"],"topic":f"{e['category']} / {e['subtopic']}",
                      "category":e["category"],"subtopic":e["subtopic"],
                      "kind":e.get("kind", "word"), "sourceSection":e.get("sourceSection", "vocabulary"),
                      "translations":{k.lower():v for k,v in e["words"].items()},
                      "source":e.get("source",{})} for e in entries]}


def write_outputs(entries: list[dict], reviews: list[dict], directory: Path,
                  pack_id="dk-5-language", title="5-Language Visual Dictionary") -> dict:
    directory.mkdir(parents=True, exist_ok=True)
    native = {"version":1,"languages":[{"code":c,"label":LANG_LABELS[c]} for c in LANGS],
              "entries":entries}
    (directory/"dictionary-native.json").write_text(json.dumps(native,ensure_ascii=False,indent=2),encoding="utf8")
    (directory/"quizlab-language-pack.json").write_text(json.dumps(to_pack(entries,pack_id,title),ensure_ascii=False,indent=2),encoding="utf8")
    with (directory/"entries-review.csv").open("w",encoding="utf-8-sig",newline="") as f:
        headers = ["approved", "id", "page", "category", "subtopic", "kind", *LANGS]
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for e in entries:
            writer.writerow({"approved":"", "id":e["id"], "page":e["source"]["page"],
                             "category":e["category"],"subtopic":e["subtopic"],
                             "kind":e.get("kind", "word"), **e["words"]})
    with (directory/"review.csv").open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f, fieldnames=["page","reason","raw","category","subtopic","x0","y0"])
        w.writeheader()
        w.writerows(reviews)
    stats = {"entries":len(entries),"content_types":dict(Counter(e.get("kind","word") for e in entries)),"review_items":len(reviews),"pages_with_entries":len(set(e["source"]["page"] for e in entries)),
             "categories":dict(Counter(e["category"] for e in entries)),
             "subtopics":dict(Counter(f"{e['category']} / {e['subtopic']}" for e in entries)),
             "notice":"Draft automated extraction. Review every entry before use; source PDF is not included."}
    (directory/"extraction-report.json").write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding="utf8")
    return stats


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("pdf",type=Path,help="Your own legally obtained PDF (not downloaded by this script)")
    ap.add_argument("--out",type=Path,default=Path("dictionary-out"))
    ap.add_argument("--from-page",type=int,default=1)
    ap.add_argument("--to-page",type=int,default=None)
    ap.add_argument("--pack-id",default="dk-5-language")
    ap.add_argument("--title",default="5-Language Visual Dictionary")
    args=ap.parse_args()
    if not args.pdf.is_file():
        ap.error(f"PDF not found: {args.pdf}")
    entries,review=parse_pdf(args.pdf,args.from_page,args.to_page)
    print(json.dumps(write_outputs(entries,review,args.out,args.pack_id,args.title),ensure_ascii=False,indent=2))

if __name__ == "__main__":
    main()
