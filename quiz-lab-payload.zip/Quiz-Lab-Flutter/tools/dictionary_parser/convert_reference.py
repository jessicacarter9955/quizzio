#!/usr/bin/env python3
"""Convert user's vocabulary JSON schema to Quiz Lab's language import schema."""
import argparse
import json
from pathlib import Path


def convert(data, pack_id='multilingual-vocabulary', title='Multilingual vocabulary'):
    if data.get('version') != 1 or not isinstance(data.get('entries'),list):
        raise ValueError('Expected {version:1, languages:[...], entries:[...]}')
    terms = []
    seen = set()
    for entry in data['entries']:
        words = {k.lower():v.strip() for k,v in entry.get('words',{}).items() if isinstance(v,str) and v.strip()}
        item_id = entry.get('id','')
        if not item_id or item_id in seen or len(words)<2:
            raise ValueError(f'Invalid or duplicate entry: {item_id}')
        seen.add(item_id)
        category = entry.get('category','general') or 'general'
        subtopic = entry.get('subtopic','general') or 'general'
        terms.append({'id':item_id,'topic':f'{category} / {subtopic}',
                      'category':category,'subtopic':subtopic,'kind':entry.get('kind','word'), 'tags':entry.get('tags',[]),
                      'translations':words,'source':entry.get('source',{})})
    return {'type':'language','id':pack_id,'title':title,'terms':terms}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input',type=Path)
    ap.add_argument('--out',type=Path,default=Path('quizlab-language-pack.json'))
    ap.add_argument('--id',default='multilingual-vocabulary')
    ap.add_argument('--title',default='Multilingual vocabulary')
    a=ap.parse_args()
    data=json.loads(a.input.read_text(encoding='utf8'))
    pack=convert(data,a.id,a.title)
    a.out.write_text(json.dumps(pack,ensure_ascii=False,indent=2),encoding='utf8')
    print(f'Exported {len(pack["terms"])} vocabulary entries to {a.out}')

if __name__ == '__main__':
    main()
