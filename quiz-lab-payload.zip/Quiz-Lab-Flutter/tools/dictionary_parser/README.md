# Five-language picture dictionary → Quiz Lab

This is a **draft extraction workflow**, not an included copy of DK's copyrighted book. It works on a PDF you obtained lawfully. The source may be borrowed through [Open Library](https://openlibrary.org/books/OL3701700M/5_language_visual_dictionary.) or purchased via [DK](https://dk.com/products/9780241413036-5-language-visual-dictionary). Availability of a loan does not guarantee a downloadable PDF. Do not bypass borrowing restrictions.

## Run (from this folder)

```sh
python -m pip install -r requirements.txt
python parser.py /path/to/your-owned-5-language-dictionary.pdf --out exported
```

Outputs:

- `exported/dictionary-native.json`: matches **your** `version:1 / languages / entries / words` schema, with EN/FR/DE/ES/IT, category, subtopic, and exact original PDF page coordinate evidence.
- `exported/quizlab-language-pack.json`: ready for Quiz Lab's **Library → Import JSON locally** (or Supabase upload).
- `exported/review.csv`: possible pairs that could not be matched confidently. Correct them against your PDF **before** importing.
- `exported/extraction-report.json`: extracted words, topics, and review counts.

The parser reads each PDF page. It recognizes five bullet-separated translations, multi-line text blocks and thematic headers. Results from a visual dictionary are **not guaranteed** because words may be positioned around imagery, in reading-order discontinuities, in embedded scans, or with unusual typography. This avoids automatically inventing matches. Some missing terms may not appear in `review.csv`, so compare page counts and visually audit.

To process specific pages:

```sh
python parser.py dictionary.pdf --from-page 50 --to-page 75 --out page-50-75
```

**Scanned PDF**: a fully image-only PDF has no selectable text. Run an OCR tool such as `ocrmypdf -l eng+fra+deu+spa+ita --deskew input.pdf input-searchable.pdf` only if you have OCR software and language packs installed; the extractor records pages with no text in the review report instead of guessing from illustrations. Even after OCR, inspect accents, hyphens, columns, alignments and visual labels carefully.

## Your existing 13-language file

Quiz Lab now imports `language-quiz(1).json` directly, including the `RU_IT` / `ZH_IT` / `KO_IT` / `JA_IT` transliteration fields and category + subtopic. Or convert it via:

```sh
python convert_reference.py language-quiz.json --out user-vocabulary-quizlab.json
```

## Important QA

1. Compare all five translations against the same labeled object in the PDF.
2. Confirm the 5-language order is EN → FR → DE → ES → IT. Edition layouts may differ.
3. Check thematic category and subcategory for every page, including pages without headers.
4. Review duplicates, inflected forms, article/gender differences, and synonymous target words.
5. Do not automatically publish the extracted content or images from a copyrighted book as an open dataset without permission.

You can use the converted JSON for your own study where your book/PDF licence permits; the tool does not package or distribute the source PDF or its images.

### Review before import (recommended)

Open `entries-review.csv` in a spreadsheet, compare each proposed row to the matching page, correct translations, category and subtopic, and mark `approved=yes`. Then create a **verified-only** quiz pack:

```sh
python approve_entries.py exported/entries-review.csv --out approved-quiz.json
```

Rows without an explicit approval will be excluded, so a scanning mismatch never becomes a silently accepted answer. `review.csv` separately lists unresolved blocks that may need new rows added manually.


### Vocabulary versus phrasebook (important)

The latest parser suggests a `kind` for each extracted label: `word`, `expression`, or `phrase`. Sentence punctuation, question structure, and headings such as *Useful phrases* are used as **hints**, not ground truth. The editable `entries-review.csv` includes `kind`; the approval script preserves a proofreader's correction. Nominal multiword terms (e.g. *traffic light*) remain vocabulary, whereas complete utterances (e.g. *Where is the station?*) belong to the phrasebook. The category → subtopic hierarchy is retained for both.

An entire book index is **not** counted as new vocabulary unless it contains verified five-language translation groups. The DK PDF has not been lawfully acquired by this project, so edition-specific page boundaries cannot be inferred from our original 400-page catalog.
