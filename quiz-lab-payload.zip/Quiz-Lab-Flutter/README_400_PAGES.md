# 400 original thematic pages

This release incrementally seeds 1,004 new language entries into existing Quiz Lab installations (808 vocabulary entries, 196 full sentence phrases) while preserving the older 800 original word entries and all answer attempts/review history. It upgrades the local SQLite schema from 1 to 2 by adding the `kind` column (default `word`) without deleting any rows.

In the Languages tab, select **Words**, **Phrases**, or **Both**. Words are prioritized separately from phrases, and the Statistics tab exposes attempts per type as well as ordinary daily and topic reports. Category -> subcategory -> item checkboxes work for either content type. The 400 PDF pages are original editorial materials (not DK book extracts), pages 1–302 vocabulary, 303–400 phrasebook.

Supabase upload continues to require separate project credentials.
